package com.uxh.modmenu;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.text.Html;
import android.util.Base64;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import java.io.File;
import android.widget.RadioGroup;
import android.widget.RadioButton;
import android.widget.CheckBox;
public class FloatingMenuService extends Service
{
    private LinearLayout mLayout, expandedView, titlelin,patchlist1,patchlist2,patchlist3,patchlist4;
    private WindowManager mWindowManager;
    public WindowManager.LayoutParams params;
    public RelativeLayout root_Container,collapsedView;
    public FrameLayout rootFrame;
    private ImageView imageIcon;
    private TextView menu1,menu2,menu3,menu4;
    private ScrollView scrollmenu1,scrollmenu2,scrollmenu3,scrollmenu4;
    
    /*
    ***  Native ***
    */
    
    private native int iconSize();
    private native String iconStr();
    private native String title();
    private native String[] flist1();
    private native String[] flist2();
    private native String[] flist3();
    private native String[] flist4();
    private native void update(int feature,int value);
    private native void update2(int feature,int value);
    private native void update3(int feature,int value);
    private native void update4(int feature,int value);
    @Override
    public IBinder onBind(Intent p1)
    {
        return null;
    }

    @Override
    public void onCreate()
    {
        super.onCreate();
        startFloatingMod();
        final Handler handler = new Handler();
        handler.post(new Runnable(){
                @Override
                public void run()
                {
                    Thread();
                    handler.postDelayed(this,1000);
                    
                }
            });           
        
    }
    private void startFloatingMod(){
        rootFrame = new FrameLayout(this);
        rootFrame.setOnTouchListener(onTouchListener());
        root_Container = new RelativeLayout(this);
        collapsedView = new RelativeLayout(this);
        collapsedView.setVisibility(View.VISIBLE);
        expandedView = new LinearLayout(this);

        /*
         *** MOD MENU ICON ***
         *** https://www.base64encode.org/
         */
        imageIcon = new ImageView(getBaseContext());
        imageIcon.setLayoutParams(new RelativeLayout.LayoutParams(-2,-2));
        int applyDimension = (int) TypedValue.applyDimension(1, iconSize(), getResources().getDisplayMetrics());
        imageIcon.getLayoutParams().width = applyDimension; 
        imageIcon.getLayoutParams().height = applyDimension;
        imageIcon.requestLayout();
        imageIcon.setScaleType(ImageView.ScaleType.FIT_XY);
        byte[] decode = Base64.decode(iconStr(),0);
        imageIcon.setImageBitmap(BitmapFactory.decodeByteArray(decode,0,decode.length));
        ((ViewGroup.MarginLayoutParams) imageIcon.getLayoutParams()).topMargin = convertDipToPixels(10);
        imageIcon.setOnTouchListener(onTouchListener());
        imageIcon.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View p1)
                {
                    collapsedView.setVisibility(View.GONE);
                    expandedView.setVisibility(View.VISIBLE);
                }
            });
        /*
         *** Mod Menu Box ***
         */
        expandedView.setVisibility(View.GONE);
        expandedView.setBackgroundColor(Color.parseColor("#45000000"));      
        expandedView.setGravity(Gravity.START);
        expandedView.setOrientation(LinearLayout.VERTICAL);
        expandedView.setPadding(0,0,0,0);
        expandedView.setLayoutParams(new LinearLayout.LayoutParams(-1,-1));
        
        
        /*
        *** Header of Mod Menu ***
        */
        titlelin = new LinearLayout(this);
        titlelin.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(60)));
        titlelin.setBackgroundColor(Color.BLACK);
        titlelin.setOnTouchListener(onTouchListener());
        titlelin.setGravity(Gravity.CENTER);
        
        
        TextView title = new TextView(this);
        title.setText(title());
        title.setTextSize(60f);
        title.setTextColor(Color.WHITE);
        title.setShadowLayer(60,1,1,Color.parseColor("#00FFFF"));
        title.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/AubreyRegular.ttf"),0);      
        title.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View p1)
                {
                    collapsedView.setVisibility(View.VISIBLE);
                    expandedView.setVisibility(View.GONE);
                }
            });
            
        LinearLayout body = new LinearLayout(this);
        body.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.MATCH_PARENT));
        body.setOrientation(LinearLayout.HORIZONTAL);     
        body.setGravity(Gravity.CENTER);
        
        LinearLayout itemlist = new LinearLayout(this);
        LinearLayout.LayoutParams layparam = new LinearLayout.LayoutParams(dp(80),-1);
        layparam.setMargins(dp(8),dp(8),dp(8),dp(8));
        itemlist.setLayoutParams(layparam);
        GradientDrawable gradientDrawable1 =new GradientDrawable();
        gradientDrawable1.setStroke(dp(2),Color.RED);
        gradientDrawable1.setColor(Color.parseColor("#202020"));
        gradientDrawable1.setCornerRadius(40);
        itemlist.setOrientation(LinearLayout.VERTICAL);
        itemlist.setBackground(gradientDrawable1);
        itemlist.setPadding(dp(8),dp(18),dp(8),dp(3));
        
        menu1 = new TextView(this);
        menu1.setText("Menu1");
        menu1.setTextColor(Color.BLACK);
        menu1.setGravity(Gravity.CENTER);
        menu1.setBackgroundColor(Color.WHITE);
        menu1.setPadding(8,16,8,16);
        LinearLayout.LayoutParams patchmenu1 = new LinearLayout.LayoutParams(-1,-2);
        patchmenu1.setMargins(0,dp(10),0,0);
        menu1.setLayoutParams(patchmenu1);
        menu1.setOnClickListener(new View.OnClickListener(){

                @Override
                public void onClick(View p1)
                {
                    menu1.setBackgroundColor(Color.WHITE);
                    menu1.setTextColor(Color.BLACK);
                    scrollmenu1.setVisibility(ScrollView.VISIBLE);
                    menu4.setBackgroundColor(Color.TRANSPARENT);
                    menu4.setTextColor(Color.WHITE);
                    menu2.setBackgroundColor(Color.TRANSPARENT);
                    menu2.setTextColor(Color.WHITE);
                    menu3.setBackgroundColor(Color.TRANSPARENT);
                    menu3.setTextColor(Color.WHITE);
                    scrollmenu4.setVisibility(ScrollView.GONE);
                    scrollmenu3.setVisibility(ScrollView.GONE);
                    scrollmenu2.setVisibility(ScrollView.GONE);             
                }
            });
        
        
        menu2 = new TextView(this);
        menu2.setText("Menu2");
        menu2.setTextColor(Color.WHITE);
        menu2.setGravity(Gravity.CENTER);
        menu2.setBackgroundColor(Color.TRANSPARENT);
        menu2.setPadding(8,16,8,16);
        //   LinearLayout.LayoutParams patchmenu1 = new LinearLayout.LayoutParams(-1,-2);
        menu2.setLayoutParams(patchmenu1);
        menu2.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View p1)
                {
                    menu2.setBackgroundColor(Color.WHITE);
                    menu2.setTextColor(Color.BLACK);
                    scrollmenu2.setVisibility(ScrollView.VISIBLE);
                    menu1.setBackgroundColor(Color.TRANSPARENT);
                    menu1.setTextColor(Color.WHITE);
                    menu4.setBackgroundColor(Color.TRANSPARENT);
                    menu4.setTextColor(Color.WHITE);
                    menu3.setBackgroundColor(Color.TRANSPARENT);
                    menu3.setTextColor(Color.WHITE);
                    scrollmenu1.setVisibility(ScrollView.GONE);
                    scrollmenu3.setVisibility(ScrollView.GONE);
                    scrollmenu4.setVisibility(ScrollView.GONE);
                }
            });
            
        menu3 = new TextView(this);
        menu3.setText("Menu3");
        menu3.setTextColor(Color.WHITE);
        menu3.setGravity(Gravity.CENTER);
        menu3.setBackgroundColor(Color.TRANSPARENT);
        menu3.setPadding(8,16,8,16);
        //   LinearLayout.LayoutParams patchmenu1 = new LinearLayout.LayoutParams(-1,-2);
        menu3.setLayoutParams(patchmenu1);
        menu3.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View p1)
                {
                    menu3.setBackgroundColor(Color.WHITE);
                    menu3.setTextColor(Color.BLACK);
                    scrollmenu3.setVisibility(ScrollView.VISIBLE);
                    menu1.setBackgroundColor(Color.TRANSPARENT);
                    menu1.setTextColor(Color.WHITE);
                    menu2.setBackgroundColor(Color.TRANSPARENT);
                    menu2.setTextColor(Color.WHITE);
                    menu4.setBackgroundColor(Color.TRANSPARENT);
                    menu4.setTextColor(Color.WHITE);
                    scrollmenu1.setVisibility(ScrollView.GONE);
                    scrollmenu4.setVisibility(ScrollView.GONE);
                    scrollmenu2.setVisibility(ScrollView.GONE);
                }
            });
            
        menu4 = new TextView(this);
        menu4.setText("Menu4");
        menu4.setTextColor(Color.WHITE);
        menu4.setGravity(Gravity.CENTER);
        menu4.setBackgroundColor(Color.TRANSPARENT);
        menu4.setPadding(8,16,8,16);
        //   LinearLayout.LayoutParams patchmenu1 = new LinearLayout.LayoutParams(-1,-2);
        menu4.setLayoutParams(patchmenu1);
        menu4.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View p1)
                {
                    
                    menu4.setBackgroundColor(Color.WHITE);
                    menu4.setTextColor(Color.BLACK);
                    scrollmenu4.setVisibility(ScrollView.VISIBLE);
                    menu1.setBackgroundColor(Color.TRANSPARENT);
                    menu1.setTextColor(Color.WHITE);
                    menu2.setBackgroundColor(Color.TRANSPARENT);
                    menu2.setTextColor(Color.WHITE);
                    menu3.setBackgroundColor(Color.TRANSPARENT);
                    menu3.setTextColor(Color.WHITE);
                    scrollmenu1.setVisibility(ScrollView.GONE);
                    scrollmenu3.setVisibility(ScrollView.GONE);
                    scrollmenu2.setVisibility(ScrollView.GONE);
                }
            });
        LinearLayout itemmenu = new LinearLayout(this);
        LinearLayout.LayoutParams lay2param = new LinearLayout.LayoutParams(-1,-1);
        lay2param.setMargins(dp(8),dp(8),dp(8),dp(8));
        itemmenu.setLayoutParams(lay2param);
        GradientDrawable gradientdrawable = new GradientDrawable();
        gradientdrawable.setStroke(dp(2),Color.RED);  
        gradientdrawable.setCornerRadius(40);
        gradientdrawable.setColor(Color.parseColor("#202020"));
        itemmenu.setBackground(gradientdrawable);
        itemmenu.setOrientation(LinearLayout.VERTICAL);
        itemmenu.setPadding(dp(8),dp(18),dp(8),dp(3));
        
        scrollmenu1 = new ScrollView(this);
        scrollmenu1.setLayoutParams(new ScrollView.LayoutParams(-1,-1));
        
        patchlist1 = new LinearLayout(this);
        patchlist1.setLayoutParams(new LinearLayout.LayoutParams(-1,-1));
        
        patchlist1.setOrientation(LinearLayout.VERTICAL);
        //Button btn = new Button(this);
        //patchlist1.addView(btn);
        listmenu1();
        
        scrollmenu1.addView(patchlist1);
        
        scrollmenu2 = new ScrollView(this);
        scrollmenu2.setVisibility(ScrollView.GONE);
        scrollmenu2.setLayoutParams(new ScrollView.LayoutParams(-1,-1));

        scrollmenu3 = new ScrollView(this);
        scrollmenu3.setVisibility(ScrollView.GONE);
        scrollmenu3.setLayoutParams(new ScrollView.LayoutParams(-1,-1));
        
        scrollmenu4 = new ScrollView(this);
        scrollmenu4.setVisibility(ScrollView.GONE);
        scrollmenu4.setLayoutParams(new ScrollView.LayoutParams(-1,-1));
        
        patchlist2 = new LinearLayout(this);
        patchlist2.setLayoutParams(new LinearLayout.LayoutParams(-1,-1));
        patchlist2.setOrientation(LinearLayout.VERTICAL);
        
        //Button btn1 = new Button(this);
       // patchlist2.addView(btn1);
        listmenu2();
        
        scrollmenu2.addView(patchlist2);
        
        patchlist3 = new LinearLayout(this);
        patchlist3.setLayoutParams(new LinearLayout.LayoutParams(-1,-1));
        patchlist3.setOrientation(LinearLayout.VERTICAL);
        listmenu3();
        scrollmenu3.addView(patchlist3);
        
        patchlist4 = new LinearLayout(this);
        patchlist4.setLayoutParams(new LinearLayout.LayoutParams(-1,-1));
        patchlist4.setOrientation(LinearLayout.VERTICAL);
        listmenu4();
        
        RadioGroup randigroup = new RadioGroup(this);
        LinearLayout.LayoutParams randiparams = new LinearLayout.LayoutParams(-1,ViewGroup.LayoutParams.WRAP_CONTENT);
        randiparams.setMargins(0,dp(5),0,0);
        randigroup.setLayoutParams(randiparams);
        
        RadioButton randibutton1 = new RadioButton(this);
        randibutton1.setText("radio1");
        randibutton1.setTextColor(Color.WHITE);
        randigroup.addView(randibutton1);
        RadioButton randibutton2 = new RadioButton(this);
        randibutton2.setText("radio2");
        randibutton2.setTextColor(Color.WHITE);
        randigroup.addView(randibutton2);
        RadioButton randibutton3 = new RadioButton(this);
        randibutton3.setText("radio1");
        randibutton3.setTextColor(Color.WHITE);
        randigroup.addView(randibutton3);
        
        patchlist4.addView(randigroup);
        scrollmenu4.addView(patchlist4);
        
        mLayout = new LinearLayout(this);
        LinearLayout.LayoutParams mParams = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT);
        mLayout.setBackgroundColor(Color.rgb(255, 255, 0));
        mLayout.setLayoutParams(mParams);
        
        if (Build.VERSION.SDK_INT >= 26) {
            params = new WindowManager.LayoutParams(-2, -2, 2038, 8, -3);
        } else {
            params = new WindowManager.LayoutParams(-2, -2, 2002, 8, -3);
        }
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = 0;
        params.y = 100;
        mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        rootFrame.addView(root_Container);
        root_Container.addView(expandedView);
        root_Container.addView(collapsedView);
        collapsedView.addView(imageIcon);
        expandedView.addView(titlelin);
        titlelin.addView(title);
        expandedView.addView(body);
        body.addView(itemlist);
        body.addView(itemmenu);
        itemlist.addView(menu1);
        itemlist.addView(menu2);
        itemlist.addView(menu3);
        itemlist.addView(menu4);
        itemmenu.addView(scrollmenu1);
        itemmenu.addView(scrollmenu2);     
        itemmenu.addView(scrollmenu3);     
        itemmenu.addView(scrollmenu4);     
        mWindowManager.addView(rootFrame,params);
    }
    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {   
            private int initialX;
            private int initialY;
            private float initialTouchX;
            private float initialTouchY;
            

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialX = params.x;
                        initialY = params.y;
                        initialTouchX = motionEvent.getRawX();
                        initialTouchY = motionEvent.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int rawX = (int) (motionEvent.getRawX() - initialTouchX);
                        int rawY = (int) (motionEvent.getRawY() - initialTouchY);
                        if (rawX < 10 && rawY < 10 && isViewCollapsed()) {                       
                            collapsedView.setVisibility(View.GONE);
                            expandedView.setVisibility(View.VISIBLE);
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = initialX + ((int) (motionEvent.getRawX() - initialTouchX));
                        params.y = initialY + ((int) (motionEvent.getRawY() - initialTouchY));
                        mWindowManager.updateViewLayout(rootFrame, params);
                        return true;
                    default:
                        return false;
                }
            }

            
        };
    }
    
    private void listmenu1()
    {
        String[] listfeatures = flist1();
        for(int i = 0; i < listfeatures.length; i++)
        {
            final int featureint = i;
            String fetchray = listfeatures[i];
            
            if(fetchray.contains("Button_"))
            {
                addButton(fetchray.replace("Button_", ""), new InterfaceBtn(){
                        @Override
                        public void OnWrite()
                        {
                            update(featureint,0);
                        }                                  
                },patchlist1);
            } else {
                if (fetchray.contains("Toggle_")) {
                    addSwitch(fetchray.replace("Toggle_", ""), new InterfaceBool() {
                            public void OnWrite(boolean z) {
                                update(featureint, 0);
                            }
                        },patchlist1);
                } else {
                    if(fetchray.contains("Head_"))
                    {
                        addHeading(fetchray.replace("Head_",""),patchlist1);
                        
                    }else {
                        if(fetchray.contains("Checkbox_"))
                        {
                            addCheckbox(fetchray.replace("Checkbox_", ""), new InterfaceBool(){

                                    @Override
                                    public void OnWrite(boolean z)
                                    {
                                        update(featureint,0);
                                    }


                                },patchlist1);
                        }
                    }
                }
            }
        }
    }
    private void listmenu2()
    {
        String[] listfeatures = flist2();
        for(int i = 0; i < listfeatures.length; i++)
        {
            final int featureint = i;
            String fetchray = listfeatures[i];

            if(fetchray.contains("Button_"))
            {
                addButton(fetchray.replace("Button_", ""), new InterfaceBtn(){
                        @Override
                        public void OnWrite()
                        {
                            update2(featureint,0);
                        }                                  
                    },patchlist2);
            } else {
                if (fetchray.contains("Toggle_")) {
                    addSwitch(fetchray.replace("Toggle_", ""), new InterfaceBool() {
                            public void OnWrite(boolean z) {
                                update2(featureint, 0);
                            }
                        },patchlist2);
                } else {
                    if(fetchray.contains("Head_"))
                    {
                        addHeading(fetchray.replace("Head_",""),patchlist2);

                    }else {
                        if(fetchray.contains("Checkbox_"))
                        {
                            addCheckbox(fetchray.replace("Checkbox_", ""), new InterfaceBool(){

                                    @Override
                                    public void OnWrite(boolean z)
                                    {
                                        update2(featureint,0);
                                    }


                                },patchlist2);
                        }
                    }
                }
            }
        }
    }
    private void listmenu3()
    {
        String[] listfeatures = flist3();
        for(int i = 0; i < listfeatures.length; i++)
        {
            final int featureint = i;
            String fetchray = listfeatures[i];

            if(fetchray.contains("Button_"))
            {
                addButton(fetchray.replace("Button_", ""), new InterfaceBtn(){
                        @Override
                        public void OnWrite()
                        {
                            update3(featureint,0);
                        }                                  
                    },patchlist3);
            } else {
                if (fetchray.contains("Toggle_")) {
                    addSwitch(fetchray.replace("Toggle_", ""), new InterfaceBool() {
                            public void OnWrite(boolean z) {
                                update3(featureint, 0);
                            }
                        },patchlist3);
                } else {
                    if(fetchray.contains("Head_"))
                    {
                        addHeading(fetchray.replace("Head_",""),patchlist3);
                    } else {
                        if(fetchray.contains("Checkbox_"))
                        {
                            addCheckbox(fetchray.replace("Checkbox_", ""), new InterfaceBool(){

                                    @Override
                                    public void OnWrite(boolean z)
                                    {
                                        update3(featureint,0);
                                    }
                                    
                                
                            },patchlist3);
                        }
                    }
                }
            }
        }
    }
    private void listmenu4()
    {
        String[] listfeatures = flist4();
        for(int i = 0; i < listfeatures.length; i++)
        {
            final int featureint = i;
            String fetchray = listfeatures[i];

            if(fetchray.contains("Button_"))
            {
                addButton(fetchray.replace("Button_", ""), new InterfaceBtn(){
                        @Override
                        public void OnWrite()
                        {
                            update4(featureint,0);
                        }                                  
                    },patchlist4);
            } else {
                if (fetchray.contains("Toggle_")) {
                    addSwitch(fetchray.replace("Toggle_", ""), new InterfaceBool() {
                            public void OnWrite(boolean z) {
                                update4(featureint, 0);
                            }
                        },patchlist4);
                } else {
                    if(fetchray.contains("Head_"))
                    {
                        addHeading(fetchray.replace("Head_",""),patchlist4);
                    }else {
                        if(fetchray.contains("Checkbox_"))
                        {
                            addCheckbox(fetchray.replace("Checkbox_", ""), new InterfaceBool(){

                                    @Override
                                    public void OnWrite(boolean z)
                                    {
                                        update4(featureint,0);
                                    }


                                },patchlist4);
                        }
                    }
                }
            }
        }
    }
    private void addHeading(String text,ViewGroup view) {
        TextView textView = new TextView(this);
        
        textView.setText(text);
       
        textView.setTextSize(14.0f);
        textView.setTextColor(Color.parseColor("#FFFFFF"));
        textView.setTypeface(null, Typeface.BOLD);
        textView.setPadding(0, 5, 0, 5);
        view.addView(textView);
    }
    
    private void addButton(String feature,final InterfaceBtn interfaceBtn,ViewGroup view)
    {
        final Button button = new Button(this);
        LinearLayout.LayoutParams paramsxd = new LinearLayout.LayoutParams(-1,-1);
        paramsxd.setMargins(0,0,0,dp(5));
        button.setLayoutParams(paramsxd);
        button.setPadding(8,16,8,16);
        button.setTextSize(12.0f);
        button.setTextColor(Color.WHITE);
        button.setGravity(Gravity.CENTER);
        button.setBackgroundColor(Color.RED);
        button.setText(feature);
        button.setOnClickListener(new View.OnClickListener(){
            private boolean active = true;
            
                @Override
                public void onClick(View p1)
                {
                    interfaceBtn.OnWrite();
                    
                    if(active)
                    {
                        active = false;
                        button.setBackgroundColor(Color.GREEN);
                        
                    } else {
                        active = true;
                        button.setBackgroundColor(Color.RED);
                    }
                }
            });
            view.addView(button);
            
    }
    private void addSwitch(String feature, final InterfaceBool sw,ViewGroup view) {
        Switch switchR = new Switch(this);
        LinearLayout.LayoutParams paramsxd = new LinearLayout.LayoutParams(-1,-1);
        paramsxd.setMargins(0,0,0,dp(5));
        switchR.setLayoutParams(paramsxd);
        switchR.setText(Html.fromHtml("<font face='roboto'>" + feature + "</font>"));
        switchR.setTextColor(Color.parseColor("#DEEDF6"));
        switchR.setPadding(10, 5, 0, 5);
        switchR.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {                 
                    sw.OnWrite(z);
                }
            });
        view.addView(switchR);
    }
    private void addCheckbox(String feature, final InterfaceBool bol, ViewGroup view)
    {
        CheckBox check1 = new CheckBox(this);
        check1.setText(feature);
        check1.setTextColor(Color.WHITE);
        check1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
                @Override
                public void onCheckedChanged(CompoundButton p1, boolean p2)
                {
                    bol.OnWrite(p2);
                }
            });
         view.addView(check1);
    }
    
    private boolean backgroundReader() {
        RunningAppProcessInfo runningAppProcessInfo = new RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(runningAppProcessInfo);
        return runningAppProcessInfo.importance != 100;
    }
    
    private void Thread()
    {
        if(rootFrame == null){
            return;
        }
        if(backgroundReader()){
            rootFrame.setVisibility(View.INVISIBLE);
        } else {
            rootFrame.setVisibility(View.VISIBLE);
        }
    }
    
    
    @Override
    public void onDestroy()
    {
        super.onDestroy();
        View view = rootFrame;
        
        if(view != null){
            mWindowManager.removeView(view);
        } 
    }

    @Override
    public void onTaskRemoved(Intent rootIntent)
    {      
        stopSelf();
        try
        {
            Thread.sleep(100);
        }
        catch (InterruptedException e)
        {
            e.printStackTrace();
        }
        super.onTaskRemoved(rootIntent);
    }
    private interface InterfaceBtn {
        void OnWrite();
    }
    private interface InterfaceBool {
        void OnWrite(boolean z);
    }
    
    private boolean isViewCollapsed()
    {
        return rootFrame == null || collapsedView.getVisibility() == View.VISIBLE;
    }
    
    private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }

    private int dp(int i) {
        return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }
}
