#include <jni.h>
#include <string.h>
#include <unistd.h>

struct patches{
    //MemoryPatch patch1, patch2;
} hexPatches;

bool feature1 = true;

extern "C"
{
    JNIEXPORT jobjectArray
    JNICALL
    Java_com_uxh_modmenu_FloatingMenuService_flist1(JNIEnv *env,jobject thiz)
    {
        jobjectArray res;
        const char *feat[] = {
            "Head_Menu 1",
            "Button_Button 1",
            "Button_Button 2",
            "Toggle_Switch 1",
            "Toggle_Switch 2",
            "Head_Heading 1",
            "Head_Heading 2",
            "Checkbox_Check 1"
        };
        
        int all_plist = (sizeof feat / sizeof feat[0]);
        
        res = (jobjectArray)env->NewObjectArray(all_plist,env->FindClass("java/lang/String"),env->NewStringUTF(""));
        int x;
        for(x = 0;x < all_plist;x++)
            env->SetObjectArrayElement(res,x,env->NewStringUTF(feat[x]));          
        return(res);
    }
    
    JNIEXPORT void 
    JNICALL
    Java_com_uxh_modmenu_FloatingMenuService_update(JNIEnv *env,jobject thiz,jint feature,jint value)
    {
        switch(feature){
            case 0:
            break;
            case 1:           
                jobject success = env->NewStringUTF("• Activated •");
                jclass toast = env->FindClass("android/widget/Toast");
                jmethodID methodMakeText = env->GetStaticMethodID(toast, "makeText", "(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;");
                if(methodMakeText == NULL){
                    return;
                }
                jobject toastobj = env->CallStaticObjectMethod(toast, methodMakeText, thiz, success, 0);
                jmethodID methodShow = env->GetMethodID(toast, "show", "()V");
			    env->CallVoidMethod(toastobj, methodShow);
            break;
        }
        
    }
    
    JNIEXPORT jobjectArray
    JNICALL
    Java_com_uxh_modmenu_FloatingMenuService_flist2(JNIEnv *env,jobject thiz)
    {
        jobjectArray res;
        const char *feat[] = {
            "Head_Menu 2",
            "Button_Button 1",
            "Button_Button 2",
            "Toggle_Switch 1",
            "Toggle_Switch 2",
            "Head_Heading 1",
            "Head_Heading 2"
        };
        
        int all_plist = (sizeof feat / sizeof feat[0]);
        
        res = (jobjectArray)env->NewObjectArray(all_plist,env->FindClass("java/lang/String"),env->NewStringUTF(""));
        int x;
        for(x = 0;x < all_plist;x++)
            env->SetObjectArrayElement(res,x,env->NewStringUTF(feat[x]));          
        return(res);
    }
    JNIEXPORT void 
    JNICALL
    Java_com_uxh_modmenu_FloatingMenuService_update2(JNIEnv *env,jobject thiz,jint feature,jint value)
    {
        
    }
    JNIEXPORT jobjectArray
    JNICALL
    Java_com_uxh_modmenu_FloatingMenuService_flist3(JNIEnv *env,jobject thiz)
    {
        jobjectArray res;
        const char *feat[] = {
            "Head_Menu 3",
            "Button_Button 1",
            "Button_Button 2",
            "Toggle_Switch 1",
            "Toggle_Switch 2",
            "Head_Heading 1",
            "Head_Heading 2"
        };
        
        int all_plist = (sizeof feat / sizeof feat[0]);
        
        res = (jobjectArray)env->NewObjectArray(all_plist,env->FindClass("java/lang/String"),env->NewStringUTF(""));
        int x;
        for(x = 0;x < all_plist;x++)
            env->SetObjectArrayElement(res,x,env->NewStringUTF(feat[x]));          
        return(res);
    }
    JNIEXPORT void 
    JNICALL
    Java_com_uxh_modmenu_FloatingMenuService_update3(JNIEnv *env,jobject thiz,jint feature,jint value)
    {
        
    }
    JNIEXPORT jobjectArray
    JNICALL
    Java_com_uxh_modmenu_FloatingMenuService_flist4(JNIEnv *env,jobject thiz)
    {
        jobjectArray res;
        const char *feat[] = {
            "Head_Menu 4",
            "Button_Button 1",
            "Button_Button 2",
            "Toggle_Switch 1",
            "Toggle_Switch 2",
            "Head_Heading 1",
            "Head_Heading 2"
        };
        
        int all_plist = (sizeof feat / sizeof feat[0]);
        
        res = (jobjectArray)env->NewObjectArray(all_plist,env->FindClass("java/lang/String"),env->NewStringUTF(""));
        int x;
        for(x = 0;x < all_plist;x++)
            env->SetObjectArrayElement(res,x,env->NewStringUTF(feat[x]));          
        return(res);
    }
    JNIEXPORT void 
    JNICALL
    Java_com_uxh_modmenu_FloatingMenuService_update4(JNIEnv *env,jobject thiz,jint feature,jint value)
    {
        
    }
}
