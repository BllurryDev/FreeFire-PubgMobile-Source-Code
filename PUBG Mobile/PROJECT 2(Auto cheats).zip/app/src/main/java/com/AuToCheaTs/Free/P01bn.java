package com.AuToCheaTs.Free;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;
import com.bumptech.glide.Glide;

import static com.bumptech.glide.Glide.*;

public class P01bn extends AppCompatActivity {
    ImageView load;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_splash);
        this.load = (ImageView) findViewById(R.id.load);
//        with((FragmentActivity) this).asGif().load(R.drawable.loading).into(this.load);
        new Handler().postDelayed(new Runnable() {
            public void run() {
                P01bn.this.startActivity(new Intent(P01bn.this, MainActivity.class));
                P01bn.this.overridePendingTransition(17432576, 17432577);
                P01bn.this.finish();
            }
        }, 3000);
    }
}
