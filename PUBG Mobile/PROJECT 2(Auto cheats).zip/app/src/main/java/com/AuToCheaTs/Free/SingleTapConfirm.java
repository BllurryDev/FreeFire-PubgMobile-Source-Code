package com.AuToCheaTs.Free;

import android.view.GestureDetector;
import android.view.MotionEvent;

/* compiled from: FloatLogo */
class SingleTapConfirm extends GestureDetector.SimpleOnGestureListener {
    public boolean onSingleTapUp(MotionEvent motionEvent) {
        return true;
    }

    SingleTapConfirm() {
    }
}
