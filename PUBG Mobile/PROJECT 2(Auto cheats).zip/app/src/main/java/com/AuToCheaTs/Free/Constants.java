package com.AuToCheaTs.Free;

public class Constants {
    public static final String ISVERIFIED = "IsVerified";
    public static final String LANGUAGE = "language";
    public static final String NONROOT = "Nonroot";
    public static final String TOKEN = "coolman";
    public static final String USER_AUTH = "FUCKYOUMAN";
}
