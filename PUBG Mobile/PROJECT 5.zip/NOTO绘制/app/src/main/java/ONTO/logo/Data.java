package ONTO.logo;

public class Data
	{

		public static int a = 0;
		public static int c = 0;
		public static int d = 0;
		public static int e = 0;

//绘制开关
		public static int getA() {
			return a;
		}

		public static void setA(int b) {
			a = b;
		}
//设置阵营开关
		public static int getC() {
			return c;
		}

		public static void setC(int o) {
			c = o;
		}


		//设置阵营开关
		public static int getD() {
			return d;
		}

		public static void setD(int o) {
			d = o;
		}

		//设置填充
		public static int getE() {
			return e;
		}

		public static void setE(int o) {
			e = o;
		}


	}
