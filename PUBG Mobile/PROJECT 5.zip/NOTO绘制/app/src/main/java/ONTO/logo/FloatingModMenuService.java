package ONTO.logo;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import static android.graphics.Typeface.BOLD;
import android.os.IBinder;
import android.text.Html;
import android.util.Base64;
import android.util.Log;
import android.app.AlertDialog;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Point;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileReader;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONObject;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;

import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import android.view.SurfaceHolder;
import java.io.File;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import static ONTO.logo.StaticActivity.cacheDir;
import android.graphics.Canvas;
import android.annotation.SuppressLint;
import android.view.Display;
import android.graphics.Point;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.TableRow;
import android.content.res.AssetManager;
import android.content.SharedPreferences;
import java.io.DataOutputStream;
import java.io.IOException;
import android.widget.EditText;
import android.opengl.Matrix;

public class FloatingModMenuService extends Service {

    public View mFloatingView;
    public TextView textView;
    private LinearLayout mButtonPanel;
    public RelativeLayout mCollapsed;
    public LinearLayout mExpanded;
    private RelativeLayout mRootContainer;
    private RelativeLayout mRootContaine;
    public WindowManager mWindowManager;
    public WindowManager.LayoutParams params;
    private LinearLayout patches;
    private FrameLayout rootFrame;
    private ImageView startimage;
    private LinearLayout view1;
    private LinearLayout view2;
    SharedPreferences configPrefs;
    
    private static boolean ks,k1,k2,k3,k4,k5,k6,k7,k8,k9,k10,k11,k12,k13,k14,k15= false;

    public static int py1=80;//自瞄范围初始化
    public static int py=0;//自瞄范围初始化
    public static int pY=0;//偏框修复
    public static int X1 = 0;//左右偏移

    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        return Service.START_NOT_STICKY;
    }
    
    private void Game()
    {
		AddText("绘制功能", 15, 1, "#000000");
		AddCheckBox("人物射线",1);
        AddCheckBox("人物骨骼",2);
		AddCheckBox("人物方框",3);
		AddCheckBox("人物名称",4);
		AddCheckBox("人物背敌",5);
		AddCheckBox("人物血量",6);
		AddCheckBox("人物编队",7);
		AddText("EPS偏移量", 10, 1, "#000000");
		
		AddText("内存功能", 15, 1, "#000000");
		AddCheckBox("自瞄",9);
        AddCheckBox("无后",10);
		AddCheckBox("防抖",11);
		AddCheckBox("聚点",12);
		AddCheckBox("范围",13);
		
		AddText("BY.尘梦如烟", 5, 1, "#000000");
	
		
		
    }
    
    @Override
    public void onCreate() {
        super.onCreate();
        initFloating();
		Game();
    }
    
 
public static void RunShell(String shell) {
        String s = shell;
        try {
            Runtime.getRuntime().exec(s, null, null);//执行
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    

    public String LJJQ()
    {
        String sb = "" + getFilesDir();
        String str = sb.substring(0, sb.indexOf("files"));
        return str + "cache/";
    }
   
    void ASeekbar(String seek) {
        SeekBar seekBar = new SeekBar(this);
        seekBar.setPadding(convertSizeToDp(15.0f), convertSizeToDp(5.0f), convertSizeToDp(15.0f), convertSizeToDp(5.0f));
        if(seek.equals("自瞄"))
        {
            final TextView textVe = new TextView(this);
            textVe.setTextColor(Color.parseColor("#000000"));
            textVe.setTypeface((Typeface) null, 1);
            textVe.setPadding(convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f));
            textVe.setTextSize(1, (float) 12);
            textVe.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
            seekBar.setProgress(50);
            textVe.setText("Fov: 100");
            seekBar.setProgress(0);
            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                @Override
                public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        py = progress;
                        py1 = 100 + py * 4;  
                        textVe.setText("Fov: " + py1);
                    }
                @Override
                public void onStartTrackingTouch(SeekBar seekBar) {
                }
                @Override
                public void onStopTrackingTouch(SeekBar seekBar) {
                }
            });
            this.patches.addView(textVe);
         }
         
        if(seek.equals("偏框"))
        {
            final TextView textVie = new TextView(this);
            textVie.setTextColor(Color.parseColor("#000000"));
            textVie.setTypeface((Typeface) null, 1);
            textVie.setPadding(convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f));
            textVie.setTextSize(1, (float) 12);
            textVie.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
            seekBar.setProgress(50);
            textVie.setText("偏移: 0");
            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        if(progress == 50) //当等于则为零
                        {
                            X1 = 0;
                            textVie.setText("偏移: " + X1);
                        }
                        if(progress < 50) //小于一半则为负数
                        {
                            X1 = -(50 - progress) * 10;
                            textVie.setText("偏移: " + X1);
                        }
                        if(progress > 50) //大于一半则为正数
                        {
                            X1 = (progress - 50) * 10;
                            textVie.setText("偏移: " + X1);
                        }
                    }
                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }
                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                    }
                });
            this.patches.addView(textVie);
        }
        
        if(seek.equals("右偏移"))
        {
            final TextView textVie = new TextView(this);
            textVie.setTextColor(Color.parseColor("#000000"));
            textVie.setTypeface((Typeface) null, 1);
            textVie.setPadding(convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f));
            textVie.setTextSize(1, (float) 12);
            textVie.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
            seekBar.setProgress(50);
            textVie.setText("偏移: 0");
            seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                        if(progress == 50) //当等于则为零
                        {
                            X1 = 0;
                            textVie.setText("偏移: " + X1);
                        }
                        if(progress < 50) //小于一半则为负数
                        {
                            X1 = -(50 - progress);
                            textVie.setText("偏移: " + X1 * 10);
                        }
                        if(progress > 50) //大于一半则为正数
                        {
                            X1 = (progress - 50);
                            textVie.setText("偏移: " + X1 * 10);
                        }
                    }
                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {
                    }
                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                    }
                });
            this.patches.addView(textVie);
        }
        
        this.patches.addView(seekBar);
    }
    
    void AddSeekbar(String str, String str2, String str3) {
        String str4 = str2;
        String str5 = str3;
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));
        linearLayout.setOrientation(0);
        TextView textView = new TextView(this);
        textView.setText(str + ":");
        textView.setTextSize(1, 12.5f);
        textView.setPadding(convertSizeToDp(10.0f), convertSizeToDp(5.0f), convertSizeToDp(10.0f), convertSizeToDp(5.0f));
        textView.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        textView.setGravity(3);
        textView.setTextColor(Color.parseColor("#000000"));
        SeekBar seekBar = new SeekBar(this);
        seekBar.setPadding(convertSizeToDp(15.0f), convertSizeToDp(5.0f), convertSizeToDp(15.0f), convertSizeToDp(5.0f));
        TextView textView2 = new TextView(this);
        textView2.setText(str4 + str5);
        textView2.setGravity(5);
        textView2.setTextSize(1, 12.5f);
        textView2.setLayoutParams(new RelativeLayout.LayoutParams(-1, -2));
        textView2.setPadding(convertSizeToDp(15.0f), convertSizeToDp(5.0f), convertSizeToDp(15.0f), convertSizeToDp(5.0f));
        textView2.setTextColor(Color.parseColor("#000000"));
        SeekBar seekBar2 = seekBar;       
        linearLayout.addView(textView);
        linearLayout.addView(textView2);
        this.patches.addView(linearLayout);
        this.patches.addView(seekBar2);
    }
    
    void AddRadioButton(String[] strArr) {
        RadioGroup radioGroup = new RadioGroup(this);
        RadioButton[] radioButtonArr = new RadioButton[strArr.length];
        radioGroup.setOrientation(1);
    
        for (int i2 = 0; i2 < strArr.length; i2++) {
            radioButtonArr[i2] = new RadioButton(this);
            radioButtonArr[i2].setTextColor(Color.parseColor("#000000"));
            radioButtonArr[i2].setPadding(convertSizeToDp(0.0f), convertSizeToDp(5.0f), convertSizeToDp(10.0f), convertSizeToDp(5.0f));
            radioButtonArr[i2].setText(strArr[i2]);
            radioButtonArr[i2].setTextSize(1, 12.5f);
            radioButtonArr[i2].setId(i2);
            radioButtonArr[i2].setGravity(5);
            radioGroup.addView(radioButtonArr[i2]);
        }
        radioGroup.setLayoutParams(new RelativeLayout.LayoutParams(-1, -2));
        this.patches.addView(radioGroup);
    }
    
    
    void AddText(String str, int i, int i2, String str2) {
        TextView textVie = new TextView(this);
        textVie.setText(str);
        textVie.setTextColor(Color.parseColor(str2));
        textVie.setTypeface((Typeface) null, i2);
        textVie.setPadding(convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f), convertSizeToDp(5.0f));
        textVie.setTextSize(1, (float) i);
        textVie.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));
        this.patches.addView(textVie);
    }
    
    
    
    
    private void initFloating() {
        rootFrame = new FrameLayout(getBaseContext());
        mRootContainer = new RelativeLayout(getBaseContext()); 
        mRootContaine = new RelativeLayout(getBaseContext()); 
        mCollapsed = new RelativeLayout(getBaseContext()); 
        mExpanded = new LinearLayout(getBaseContext()); 
        view1 = new LinearLayout(getBaseContext());
        patches = new LinearLayout(getBaseContext());
        view2 = new LinearLayout(getBaseContext());
        mButtonPanel = new LinearLayout(getBaseContext()); 

        RelativeLayout relativeLayout = new RelativeLayout(this);
        relativeLayout.setLayoutParams(new RelativeLayout.LayoutParams(-2, -1));
        relativeLayout.setPadding(3, 0, 3, 3);
        relativeLayout.setVerticalGravity(16); 

        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams2.gravity = 17;

        
        TextView textView = new TextView(getBaseContext());
        textView.setText("ONTO");
        textView.setTextColor(Color.parseColor("#000000"));
        textView.setTypeface(Typeface.DEFAULT_BOLD);
        textView.setTextSize(20.0f);
        textView.setPadding(10, 10, 10, 5);
        textView.setLayoutParams(layoutParams2);
        textView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    mCollapsed.setVisibility(View.VISIBLE);
                    mExpanded.setVisibility(View.GONE);
                }
            });
      
        TextView textView2 = new TextView(getBaseContext());
        textView2.setText("v1.0");
        textView2.setTextColor(Color.parseColor("#000000"));
        textView2.setTypeface(Typeface.DEFAULT_BOLD);
        textView2.setTextSize(10.0f);
        textView2.setPadding(10, 5, 10, 10);
        
		

        this.mExpanded.addView(textView);
        this.mExpanded.addView(textView2);
		

        rootFrame.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        mRootContainer.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        mRootContaine.setLayoutParams(new FrameLayout.LayoutParams(-2, -2));
        mCollapsed.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        mCollapsed.setVisibility(View.VISIBLE);
        startimage = new ImageView(getBaseContext());
        startimage.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        int applyDimension = (int) TypedValue.applyDimension(1, 50, getResources().getDisplayMetrics());
        startimage.getLayoutParams().height = applyDimension;
        startimage.getLayoutParams().width = applyDimension;
        startimage.requestLayout();
        startimage.setScaleType(ImageView.ScaleType.FIT_XY);
        byte[] decode = Base64.decode("iVBORw0KGgoAAAANSUhEUgAAAGAAAABgCAYAAADimHc4AAAAAXNSR0IArs4c6QAAAARzQklUCAgICHwIZIgAAAecSURBVHic7Z3tdds2FIZf9PR/2QnKTFBlgjITxJ0gygROJ7A6QbyBlQnsTCB1AksTiJlAygRvf1wyYkkQAAmAkFQ+5+jYlvFxeQFcABcfBGZmZmZmZmZmZmZm/m+o1AKYIJkB+B3AAkBe/UT1e94KXlYfANhVv+8A7JVSp5hy+nBxBUDyPYCi+iyMgd3ZAdgC2CqlvgZK83YgWZB8InlkfI5VXkXq504OyQ8kDxMovY8DyQ+p9TApJDOSD4kV3+ZAkSlLrZ+okLzjZSm+zYHkXWo9BYdkTvI5rW4H8UwyT623IFBq/RSda2iOvPbWQPJzai0G4HNMHUWZB1A6sw3CjeN92APQTcT+GJDGDsC7GBO64AWQUPnfIZOtetK1symskrWoPncAfjMEj1YIwSC54LT2/kRyzUC2mtJfbQ35HUleQqvuQhnfT6X8HcklI43bq7RPPXkfY+U7GoryXyMrva7tk9RASmvuK4TXUIUQpA8g+Yp4Nv87gEcAj2Psb1Vgv1R/5gAyiD0HLJ5Sir9o0/PvnVLq7VB5gkPyMWKNXw2taSTfU4a/G8d8DjS4IWh+vscwWhwJpdOKwUufQjQyZBSnnu9M+0hyqUk/t8RLM1mrBAvd6ZZ0dBNX+X+OIEMn/0quPo5M4bZgeN+Ok7mhrB3E9Cu9avI0DU1J8jmOlvuVENL0lHQY2VBGJZuA+faiyfvFIVoRRdkaYTKGcynvaKn1FFPzFCg/JzQy2FoAKToZPDT9aWgEAJ/QXRAfwxel1MIyDHwA8ApgGSA/V76NjJdjCjkZptMzCkoxN7Endn2sNfK4coil91qQZYAHXFryuA+Qhw9FS56h/Z3x+XwL4OD5cL3CUfqW1KtmW41c64FpxGkFlOGfD2uL8lOZnJoTW6Mxjp/rFDEKYGhNaLIzpDu1C7uPZcBnXscoAB8l5T1pTunCNtHx6VAqxliOoZXvM/FaGdJNbXZI/agnhEl08hG5zgMKx3BtaldyB0qtS7269FEptdR8/wR/2QrP+Gc8asOqJz2bhzE2O/a4Pxhu1t3xKY1VfuYhRN6Tpk+H7sOJZpP4FDg//1Uzjh9+mkY+Qzte22K5DePiDqWSbTzS76Ow6delDxhrC7UFQGn6Q2vGQilVAPgb0q+48B3AFwB/KqUypdRK53eidJYHhLTZZ6y6+9khkXxk5mXP92Oa5T3JF6XUCsCqUlqB7gNuIZuwtkqp3hYI/FjvfUAcxdfk3ilwfNN/6UlvrEnTLhkOfJZ6+XIzUoahbH3krYX2sb2d2k7/EdCGA6b6lAnVPdP4mawFYN2WQnEu5a4P3OKjUmqtSbOEeRugCyectyG2qfuZwjMPX0ql1BtTAJcC6KwQDUC7d4ZiSp480r0alFJGHY9ZERvCgppxd9Uq9pHzvgpit4Cat+1RCWWStsN519pNkroF1GzYmvorpUqIjXYd198kLgUwdpG6SQbgia1RUdUqCtxuIVh151IApb8cAGRkctC0hF31v1vsE0pbgKlMUE0GMUf/8ZU3zNGXieVJjksBGKf0I8gAPLN1+E0pdap8838Fzi8lVt1NaYLafKLMavPml0qpRwBvcRv9QmkLkKIFNCkAvLLl46n6hRzX3y9YdecyD8gAhF1k1vMCcV38cBlXeW8hdwZdI7/aTvU4HVGiLK5MoYQTxH+/beSdQdaVd/Wnx6+fQY6aFgAu4QaUvVIqzJo34x1D6uPBU96MsgKWEqfjSy4LMoCYgfvRGhnOG5JZu6bzfIVZjrOHtoR4Hf+pw1XxVhR38AvSuDu2QVNj/5HNkLzQcNyHspvBxIHi+88bcUzHTWMR/jQ94+5k0J4NY+s2K7qblSPJ+0a8ELu6h7COUQC+m3P76OxWqPI6VP8vGt8P3aH31Ihraz0hKRADmk8LDqVT6ymdZ/uKm6VnJbir4n7ylNeVcohOh/qCVgPD97GHbDXZ1l9QnHSvkCNQTXLPvGqXR8wJZZNV1NTp3wrW7Joc061ad41wY83gooofm3KoPsd4Q9cj4tR8VUotW7PdJYBn9O8XKj3yq8k4zWHq+FcXUOz0mFZQslvzbYcz2vOAUXa8iht7JNR5vpiFMOa8QKFJx7bretUK73JgupMGw55t7qPzfFHhMGV0OkDaa2TZCj/mNM0j4228baLdBRgVyg431xlme2QDmpWiOzA31IQ8c5qrkU9Mdcco3U1RoYlreqC7VtgpTMhY0t4tSjdPaaGJp6Ok5uSKYx4pSHthUw3t0/xCE6fpWyqpMVNVuKn9OK5MNbGzQzERpkLoU25uSbfgZRxjbWO95WVyKIXQ1ykPPr7P9HdG9HHipSm/hmbfu7YVaNLIOd0BiqF0RmcXB83m6IEas0NR+gemv6zDRBSzE/Py7i3MC/nb6mcRQ4bA7AEUF31vtA5e7vBxCJcx1BwLZbI29ZpsCDoTwquFYuPHONJSYdwccLVQWkPIZc3QaDcH3BQ8b5q6pIIoKWsNlzm+jwXFzZCyIErGvGTvWqC4HNacprOu30NQpH5u4DJf5llvsC0QbkPwHueXeU6/eGLg4gqgCcUmL6B/nW37pP036F9na32Zz8zMzMzMzMzMzMzMzJT8C+VjiIsbEtgSAAAAAElFTkSuQmCC", 0);
        startimage.setImageBitmap(BitmapFactory.decodeByteArray(decode, 0, decode.length));
        startimage.setImageAlpha(200);
        ((ViewGroup.MarginLayoutParams) startimage.getLayoutParams()).topMargin = convertDipToPixels(10);

        this.mExpanded.setVisibility(View.GONE);
        this.mExpanded.setBackgroundColor(Color.parseColor("#FFFFFF"));
        this.mExpanded.setGravity(17);
        this.mExpanded.setOrientation(LinearLayout.VERTICAL);
        this.mExpanded.setPadding(0, 0, 0, 0);
        this.mExpanded.setLayoutParams(new LinearLayout.LayoutParams(-1, -2));

        ScrollView scrollView = new ScrollView(getBaseContext());
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(200)));
        scrollView.setBackgroundColor(Color.parseColor("#FFFFFF"));

        this.view1.setLayoutParams(new LinearLayout.LayoutParams(-1, 5));
        this.view1.setBackgroundColor(Color.parseColor("#FFFFFF"));
        this.patches.setLayoutParams(new LinearLayout.LayoutParams(-1, -1));
        this.patches.setOrientation(LinearLayout.VERTICAL);
        this.view2.setLayoutParams(new LinearLayout.LayoutParams(-1, 5));
        this.view2.setBackgroundColor(Color.parseColor("#FFFFFF"));
        this.view2.setPadding(0, 0, 0, 10);
        this.mButtonPanel.setLayoutParams(new LinearLayout.LayoutParams(-2, -2));

        LinearLayout.LayoutParams layoutParams3 = new LinearLayout.LayoutParams(-2, -2);
        layoutParams3.gravity = 17;
        
       mExpanded.setVisibility(View.VISIBLE);

        new LinearLayout.LayoutParams(-1, dp(25)).topMargin = dp(2);
        this.rootFrame.addView(this.mRootContainer);
        this.rootFrame.addView(this.mRootContaine);
        this.mRootContainer.addView(this.mCollapsed);
        this.mRootContaine.addView(this.mExpanded);
        this.mCollapsed.addView(this.startimage);
        this.mExpanded.addView(this.view1);
        this.mExpanded.addView(scrollView);
        scrollView.addView(this.patches);
        this.mExpanded.addView(this.view2);
        this.mExpanded.addView(relativeLayout);
        this.mFloatingView = this.rootFrame;
        if (Build.VERSION.SDK_INT >= 26) {
            this.params = new WindowManager.LayoutParams(-2, -2, 2038, 8, -3);
        } else {
            this.params = new WindowManager.LayoutParams(-2, -2, 2002, 8, -3);
        }
        WindowManager.LayoutParams layoutParams4 = this.params;
        layoutParams4.gravity = 51;
        layoutParams4.x = 0;
        layoutParams4.y = 100;
        this.mWindowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        this.mWindowManager.addView(this.mFloatingView, this.params);
        RelativeLayout relativeLayout2 = this.mCollapsed;
        LinearLayout linearLayout = this.mExpanded;
        this.mFloatingView.setOnTouchListener(onTouchListener());
        initMenuButton(relativeLayout2, linearLayout);
    }
    

    void AddCheckBox(final String name,final int Tz) {
        CheckBox CheckBox = new CheckBox(this);
        CheckBox.setText(Html.fromHtml("<font face='roboto'>"+ name + "</font>"));
        CheckBox.setTextColor(Color.parseColor("#000000"));
        CheckBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
					if(Tz==1){
                      
                 
                }
				}
            });
        this.patches.addView(CheckBox);
    }

    private View.OnTouchListener onTouchListener() {
        return new View.OnTouchListener() {
            final View collapsedView = FloatingModMenuService.this.mCollapsed;
            private float initialTouchX;
            private float initialTouchY;
            private int initialX;
            private int initialY;

            public boolean onTouch(View view, MotionEvent motionEvent) {
                switch (motionEvent.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        this.initialX = FloatingModMenuService.this.params.x;
                        this.initialY = FloatingModMenuService.this.params.y;
                        this.initialTouchX = motionEvent.getRawX();
                        this.initialTouchY = motionEvent.getRawY();
                        return true;
                    case MotionEvent.ACTION_UP:
                        int rawX = (int) (motionEvent.getRawX() - this.initialTouchX);
                        int rawY = (int) (motionEvent.getRawY() - this.initialTouchY);
                        if (rawX < 10 && rawY < 10 && FloatingModMenuService.this.isViewCollapsed()) {
                            this.collapsedView.setVisibility(View.GONE);
                            mExpanded.setVisibility(View.VISIBLE);
                        }
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        FloatingModMenuService.this.params.x = this.initialX + ((int) (motionEvent.getRawX() - this.initialTouchX));
                        FloatingModMenuService.this.params.y = this.initialY + ((int) (motionEvent.getRawY() - this.initialTouchY));

                        FloatingModMenuService.this.mWindowManager.updateViewLayout(FloatingModMenuService.this.mFloatingView, FloatingModMenuService.this.params);
                        return true;
                    default:
                        return false;
                }
            }
        };
    }

    private void initMenuButton(final View view2, final View view3) {
       
    }

    

    boolean delayed;
 
    public boolean isViewCollapsed() {
        return this.mFloatingView == null || this.mCollapsed.getVisibility() == View.VISIBLE;
    }

    private int convertDipToPixels(int i) {
        return (int) ((((float) i) * getResources().getDisplayMetrics().density) + 0.5f);
    }

    private int dp(int i) {
        return (int) TypedValue.applyDimension(1, (float) i, getResources().getDisplayMetrics());
    }
 
    public void onDestroy() {
        super.onDestroy();
        View view = this.mFloatingView;
        if (view != null) {
            this.mWindowManager.removeView(view);
        }
    }

    private boolean isNotInGame() {
        RunningAppProcessInfo runningAppProcessInfo = new RunningAppProcessInfo();
        ActivityManager.getMyMemoryState(runningAppProcessInfo);
        return runningAppProcessInfo.importance != 100;
    }

    public void onTaskRemoved(Intent intent) {
        stopSelf();
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        super.onTaskRemoved(intent);
    }


    public void Thread() {
        if (this.mFloatingView == null) {
            return;
        }
        if (isNotInGame()) {
            this.mFloatingView.setVisibility(View.INVISIBLE);
        } else {
            this.mFloatingView.setVisibility(View.VISIBLE);
        }
    }

    private interface InterfaceBtn {
        void OnWrite();
    }

    private interface InterfaceInt {
        void OnWrite(int i);
    }

    private interface InterfaceBool {
        void OnWrite(boolean z);
    }

    int convertSizeToDp(float f) {
        return Math.round(TypedValue.applyDimension(1, f, getResources().getDisplayMetrics()));
    }
   

	



    
    
}


