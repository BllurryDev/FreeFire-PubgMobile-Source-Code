package ONTO.logo;

import android.app.Activity;
import android.os.Bundle;

import ONTO.logo.R;

public class MainActivity extends Activity {
	public static int 偏移量=0;//方框偏移左右
	public static int 屏幕高,屏幕宽;
	
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        StaticActivity.Start(this);
    }
}
