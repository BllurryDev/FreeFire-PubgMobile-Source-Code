package ONTO.logo;


public class Storagevariable
{
   
    private static int f = 0;//左右偏移
	

	public static int getF()
	{
        return f;
    }
    public static void setF(int f)
	{
        Storagevariable.f = f;
    }

	
}

