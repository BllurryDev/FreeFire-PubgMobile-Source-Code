package ONTO.logo;
 

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.icu.text.SimpleDateFormat;
import android.os.Build;
import android.os.IBinder; 
import android.view.Gravity;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import ONTO.logo.R;
import ONTO.logo.MainActivity;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Date;
import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Display;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.app.Activity;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.annotation.SuppressLint;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationSet;
import android.view.animation.RotateAnimation;
import android.view.animation.TranslateAnimation;
import android.net.*;
import android.os.*;
import android.provider.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.widget.CompoundButton.*;
import static android.graphics.Typeface.BOLD;
import java.io.*;
import java.math.*;
import java.net.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import org.w3c.dom.*;
import android.app.*;
import android.content.*;
import android.graphics.*;
import android.net.*;
import android.os.*;
import android.provider.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.widget.CompoundButton.*;
import java.io.*;
import java.net.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import java.util.Base64;
import java.util.zip.ZipFile;
import java.nio.charset.Charset;
import java.util.zip.ZipEntry;
import android.content.res.Resources;



public class DrawService extends Service {
	int FPS = 60;
    private int    mFPS = 0;
    private int    mFPSCounter = 0;
    private long   mFPSTime = 0;

	int hero =0;
 
    private boolean 绘制状态;//线程是否继续
    private boolean viewAdded = false;
	public static boolean NB = false;
    private View view;
    private SurfaceView sv;//绘制悬浮
    private WindowManager wm;//悬浮窗
    private WindowManager.LayoutParams params;
	private static WindowManager mwindow;
	private static WindowManager.LayoutParams lparam;
	public static int PMy,PMx;
	public static int PY = 0;
    
    private boolean Game = true;//游戏数据获取状态，true:没有获取，false:已经获取
    

    //获取版权
	public native String ONTONB();

	
    public static String 射线 = "false", 方框 = "false", 骨骼 = "false", 名字 ="false", 血量 = "false", 距离 = "false ", 预警 = "false", 物资 = "false", 调试 = "false";

    public static String 射线() {
	return 射线;
		}
    public static String 方框() {
	return 方框;
		}
    public static String 骨骼() {
	return 骨骼;
		}
    public static String 名字() {
	return 名字;
	}
    public static String 血量() {
	return 血量;
		}
    public static String 距离() {
	return 距离;
		}
    public static String 预警() {
        return 预警;
    }
    public static String 物资() {
        return 物资;
    }
    public static String 调试() {
        return 调试;
    }
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @SuppressLint("RtlHardcoded")
    @Override
    public void onCreate() {
        WindowManager windowManager = (WindowManager) getSystemService(MainActivity.WINDOW_SERVICE);
        assert windowManager != null;
        Display display = windowManager.getDefaultDisplay();
        Point outPoint = new Point();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN_MR1) {
            display.getRealSize(outPoint);
        }
		mwindow=(WindowManager)getApplicationContext().getSystemService(WINDOW_SERVICE);
		lparam=new WindowManager.LayoutParams();
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            lparam.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        } else {
            lparam.type = WindowManager.LayoutParams.TYPE_PHONE;
        }
		display.getRealSize(outPoint);
		
       // int 屏高= 
        view = View.inflate(getApplicationContext(), R.layout.msdk_thrdcall_dlg_griditem, null);
        sv = view.findViewById(R.id.fill);
        sv.getHolder().setFormat(PixelFormat.TRANSLUCENT);
        sv.getHolder().addCallback(new SurfaceHolder.Callback() {
                private DrawThread dt;
				
				

                @Override
                public void surfaceCreated(SurfaceHolder surfaceHolder) {
					绘制状态 = true;
                    dt = new DrawThread(surfaceHolder);
                    dt.Flag = true;
                    dt.start();

                }

                @Override
                public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i1, int i2) {

                }

                @Override
                public void surfaceDestroyed(SurfaceHolder surfaceHolder) {

                    dt.Flag = false;


                }
            });
        wm = (WindowManager) this.getSystemService(WINDOW_SERVICE);
        params = new WindowManager.LayoutParams();
        params.width = WindowManager.LayoutParams.MATCH_PARENT;
        params.height = WindowManager.LayoutParams.MATCH_PARENT;

        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.O) {
            // android 8.0及以后使用
            params.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
            params.flags = computeFlags(WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL);
        } else {
            // android 8.0以前使用
            params.type = WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY;
            params.flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
        }
        
        params.gravity = Gravity.LEFT | Gravity.TOP;
        params.format = PixelFormat.RGBA_8888;

        super.onCreate();
        
}
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        if (viewAdded) {
            wm.updateViewLayout(view, params);
        } else {
            wm.addView(view, params);
            viewAdded = true;
        }
        return super.onStartCommand(intent, flags, startId);
    }

    //销毁服务
    @Override
    public void onDestroy() {

        if (viewAdded && wm != null) {
            wm.removeView(view);
        }
        super.onDestroy();
    }

    
    //适配低版本悬浮窗
    private int computeFlags(int curFlags) {
        boolean mTouchable = false;
        if (!mTouchable) {
            curFlags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        } else {
            curFlags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        }

        boolean mFocusable = false;
        if (!mFocusable) {
            curFlags |= WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        } else {
            curFlags &= ~WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        }

        boolean mTouchModal = true;
        if (!mTouchModal) {
            curFlags |= WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
        } else {
            curFlags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
        }

        boolean mOutsideTouchable = false;
        if (mOutsideTouchable) {
            curFlags |= WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;
        } else {
            curFlags &= ~WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH;
        }

        return curFlags;
    }

    class DrawThread extends Thread {
        private boolean Flag;//用于标注线程是否继续

        private SurfaceHolder surfaceHolder;



        //定义画笔
        Paint paint9 = new Paint();Paint painttime = new Paint();
        Paint paint10 = new Paint(); Paint paint13 = new Paint();
        Paint paint14 = new Paint();Paint paint201= new Paint();
        Paint DB = new Paint();
        Paint tS = new Paint();
        Paint YQ = new Paint();
        Paint logo = new Paint();
        Paint BQM = new Paint();
		Paint paint = new Paint();
        Paint painto1 = new Paint();
        Paint 人机射线 = new Paint();
		
        Paint 人数背景 = new Paint();
		Paint 人数背景2 = new Paint();
	
		Paint 玩家射线 = new Paint();
        Paint 人机方框 = new Paint();
        Paint paint20 = new Paint();
        Paint paint55 = new Paint();
        Paint 血条边框 = new Paint();
        Paint 血条背景 = new Paint();
        Paint 距离颜色 = new Paint();
        Paint 血量颜色 = new Paint();
        Paint 名字颜色 = new Paint();
        Paint 人机颜色 = new Paint();
		Paint number = new Paint();
        Paint paintd = new Paint();
        Paint 人物人数 = new Paint();
		Paint painto = new Paint();
		Paint paint21 = new Paint();
		Paint paint03 = new Paint();
		Paint paint3 = new Paint();
		Paint paint32 = new Paint();
		Paint paint11 = new Paint();
		Paint painto2 = new Paint();
        Paint paint16 = new Paint();
        Paint paint18= new Paint();
        Paint 玩家方框 = new Paint();
        Paint 黑色= new Paint();
        Paint blue_dot= new Paint();Paint blue_dot1= new Paint();
        Paint Q= new Paint();
        Canvas canvas=null;
        float x=0;
        float y=0;
        float w=0;
        float h=0;
        float m=0;
		float 血量判断 = 0;//血量判断
		float 人机判断 = 0;//人机判断
		float 动作判断 = 0;//人机判断
		float 持枪判断 = 0;//持枪判断
		float 能量判断 = 0;//能量判断
		float 倒地血条 = 0;//倒地血量
		float 队伍序号 = 0;//队伍序号
		float 视角判断 = 0;//视角判断
		float 一号武器 = 0;//手持武器
		float 二号武器 = 0;//手持武器
        float 雷达x = 0;//手持武器
		float 雷达y = 0;//手持武器
		String 人物名称="";//人物名称

		int 真人=0;
        int 人机=0;
		
        int RSD;
        int wz ;
        int M ;
        float rs;
        float ai;
        float hp;
        int bh;
        int rsA=0;
        float x1 = 0;//左右偏移
        String name="";
        float ggtzy = 0;
        float ggtgd = 0;
        float ggsbzy = 0;
        float ggsbsx = 0;
        float ggpgzy = 0;
        float ggpgsx = 0;
        float ggzjzy = 0;
        float ggzjsx = 0;
        float ggyjzy = 0;
        float ggyjsx = 0;
        float ggzszzy = 0;
        float ggzszsx = 0;
        float ggysjzy = 0;
        float ggysjsx = 0;
        float ggzswzy = 0;
        float ggzswsx = 0;
        float ggyswzy = 0;
        float ggyswsx = 0;
        float ggzdtzy = 0;
        float ggzdtsx = 0;
        float ggydtzy = 0;
        float ggydtsx = 0;
        float ggzxgzy = 0;
        float ggzxgsx = 0;
        float ggyxgzy = 0;
        float ggyxgsx = 0;
        float ggzjwzy = 0;
        float ggzjwsx = 0;
        float ggyjwzy = 0;
        float ggyjwsx = 0;
        
        
        
        private  String getFileContent(File file) {
            String content = "";
            if (!file.isDirectory()) {
                try {
                    InputStream instream = new FileInputStream(file);
                    if (instream != null) {
                        InputStreamReader inputreader
                            = new InputStreamReader(instream, "UTF-8");
                        BufferedReader buffreader = new BufferedReader(inputreader);
                        String line = "";
                        while ((line = buffreader.readLine()) != null) {
                            content += line;
                        }
                        instream.close();//关闭输入流
                    }
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return content;
        }

        public DrawThread(SurfaceHolder h) {
            init();
            surfaceHolder = h;
            Flag = true;
        }
        
        
        public String 获取车俩(int id) {
            String name="";
            if (id == 70) {
                name = "摩托车";
            }
            if (id == 71) {
                name = "小绵羊";
            }
            if (id == 72) {
                name = "三轮摩托车";
            }
            if (id == 73) {
                name = "三轮摩托";
            }
            if (id == 74) {
                name = "跑车";
            }
            if (id == 75) {
                name = "小轿车";
            }
            if (id == 76) {
                name = "皮卡车";
            }
            if (id == 77) {
                name = "蹦蹦车";
            }
            if (id == 78) {
                name = "吉普车";
            }
            if (id == 79) {
                name = "游艇";
            }

            return name;
        }

        public String 获取背包(int id) {
            String name="";
            if (id == 1) {
                name = "一级包";
            }
            if (id == 2) {
                name = "二级包";
            }
            if (id == 3) {
                name = "三级包";
            }
            return name;
        }



        public String 获取护甲(int id) {
            String name="";
            if (id == 4) {
                name = "一级甲";
            }
            if (id == 5) {
                name = "一级头";
            }
            if (id == 6) {
                name = "二级甲";
            }
            if (id == 7) {
                name = "二级头";
            }
            if (id == 8) {
                name = "三级头";
            }
            if (id == 9) {
                name = "三级甲";
            }
            return name;
        }
        public String 获取空投(int id) {
            String name="";
            if (id == 10) {
                name = "空投箱";
            }
            if (id == 11) {
                name = "盒子";
            }
            return name;
        }

        public String 获取药品(int id) {
            String name="";
            if (id == 21) {
                name = "止痛药";
            }
            if (id == 22) {
                name = "肾上腺素";
            }
            if (id == 23) {
                name = "饮料";
            }
            if (id == 24) {
                name = "盒子";
            }
            if (id == 25) {
                name = "空投箱";
            }
            return name;
        }

        public String 获取枪类(int id) {
            String name="";
            if (id == 31) {
                name = "M416";
            }
            if (id == 32) {
                name = "M16A4";
            }
            if (id == 33) {
                name = "SCAR";
            }
            if (id == 34) {
                name = "QBZ";
            }
            if (id == 35) {
                name = "M762";
            }
            if (id == 36) {
                name = "MK47";
            }
            if (id == 37) {
                name = "Groza";
            }
            if (id == 38) {
                name = "AWM";
            }
            if (id == 39) {
                name = "Kar98k";
            }
            if (id == 40) {
                name = "M24";
            }
            if (id == 41) {
                name = "Mini14";
            }
            if (id == 42) {
                name = "SKS";
            }
            if (id == 43) {
                name = "QBU";
            }
            return name;
        }


        public String 获取子弹(int id) {
            String name="";
            if (id == 46) {
                name = "5.56";
            }
            if (id == 47) {
                name = "7.62";
            }

            return name;
        }

        public String 获取倍镜(int id) {
            String name="";
            if (id == 54) {
                name = "4倍镜";
            }
            if (id == 55) {
                name = "6倍镜";
            }
            if (id == 56) {
                name = "8倍镜";
            }
            return name;
        }


        public String 获取配件(int id) {
            String name="";
            if (id == 48) {
                name = "步枪快速扩容";
            }
            if (id == 49) {
                name = "步枪扩容";
            }
            if (id == 50) {
                name = "狙击快速扩容";
            }
            if (id == 51) {
                name = "狙击扩容";
            }
            if (id == 52) {
                name = "步枪消音";
            }
            if (id == 53) {
                name = "狙击消音";
            }
            return name;
        }
        

        private void init() {
			//红点
			paint.setColor(Color.rgb(255, 0, 0));
			paint.setStyle(Paint.Style.FILL);//设置样式
			paint.setStrokeWidth(3.5f);//设置笔划宽度
            //绘制文本
            玩家射线.setColor(Color.rgb(255, 255, 255));
            玩家射线.setStyle(Paint.Style.FILL);
            玩家射线.setStrokeWidth(1.9f);

            //人机射线
            人机射线.setColor(Color.rgb(255, 255, 255));
            人机射线.setStyle(Paint.Style.FILL);
            人机射线.setStrokeWidth(1.8f);

            //人机方框
            人机方框.setColor(Color.GREEN);
            人机方框.setStyle(Paint.Style.STROKE);
            人机方框.setStrokeWidth(2f);

            血条边框.setColor(Color.rgb(255, 255, 255));
            血条边框.setStyle(Paint.Style.STROKE);
            血条边框.setStrokeWidth(1f);;

            血条背景.setColor(Color.rgb(255, 255, 255));
            血条背景.setStrokeWidth(25f);
            血条背景.setStyle(Paint.Style.FILL);
            血条背景.setAlpha(90);
			
            //玩家方框
            玩家方框.setColor(Color.rgb(255, 255, 255));
            玩家方框.setStyle(Paint.Style.STROKE);
            玩家方框.setStrokeWidth(2f);

            黑色.setColor(0xFF000000);
            黑色.setStyle(Paint.Style.FILL);
            黑色.setStrokeWidth(10);
            黑色.setAlpha(200);

            //运行时间
            painttime.setColor(Color.rgb(255, 255, 255));//字体颜色
            painttime.setStrokeWidth(7);
            painttime.setTextSize(35);//字体大0小
            paintd.setColor(0xff00ff84);//字体颜色
            Typeface font1 = Typeface.create(Typeface.SANS_SERIF, BOLD);//加载字体
            paintd.setTypeface(font1);//设置字体
            paintd.setStrokeWidth(30);
            paintd.setTextSize(55);//字体大0小
			//人物射线
           // paint1.setColor(Color.GREEN);
           // paint1.setStyle(Paint.Style.STROKE);
           // paint1.setStrokeWidth(2f);
			
            painto.setColor(0xff00ff00);//字体颜色
            Typeface font8= Typeface.create(Typeface.SANS_SERIF, BOLD);//加载字体
            painto.setStrokeWidth(30);
            painto.setTextSize(28);//字体大0小
            
			painto2.setColor(Color.RED);//字体颜色
            painto2.setStrokeWidth(30);
            painto2.setTextSize(28);//字体大0小
			
            painto1.setStrokeWidth(3);//描边大小
            painto1.setTextSize(28);//字体大小z
            painto1.setAlpha(200);//透明性
            painto1.setStyle(Paint.Style.STROKE);//描边

            //背敌距离
            paint9.setColor(Color.rgb(255, 255, 255));
            paint9.setStyle(Paint.Style.FILL);
            paint9.setTextSize(25);
            paint9.setAlpha(205);
            //背敌
            paint10.setColor(Color.rgb(255, 0, 0));
            paint10.setStyle(Paint.Style.FILL);
            paint10.setTextSize(15);
            paint10.setAlpha(130);
			paint11.setColor(Color.GREEN);
            paint11.setStyle(Paint.Style.FILL);
            paint11.setTextSize(15);
            paint11.setAlpha(130);
            //血填充
            paint16.setColor(Color.parseColor("#75D701"));
            paint16.setStyle(Paint.Style.FILL);
            paint16.setTextSize(40);
            paint16.setStrokeWidth(8);//线条宽度

            //血外框
            paint18.setColor(Color.parseColor("#090707"));
            paint18.setStyle(Paint.Style.STROKE);
            paint18.setStrokeWidth(8);//线条宽度
			paint18.setAlpha(90);
            paint201.setColor(Color.rgb(255, 255, 255));
            paint201.setTextSize(18);//字体大小
			
			paint21.setColor(Color.rgb(255, 255, 255));
            paint21.setTextSize(18);//字体大小
			
            paint13.setStrokeWidth(3);//描边大小
            paint13.setTextSize(24);//字体大小z
            paint13.setAlpha(200);//透明性
            paint13.setStyle(Paint.Style.STROKE);//描边

            paint14.setColor(Color.rgb(255, 215, 0));//字体颜色
            paint14.setStrokeWidth(30);
            paint14.setTextSize(24);//字体大0小
            
            blue_dot.setColor(Color.rgb(255, 0, 0));
            blue_dot.setStyle(Paint.Style.FILL);
            blue_dot.setStrokeWidth(12);

            blue_dot1.setColor(Color.parseColor("#DA70D6"));
            blue_dot1.setStyle(Paint.Style.FILL);
            blue_dot1.setStrokeWidth(12);
            
            logo.setColor(0xFFFFFFFF);//字体颜色
            logo.setStrokeWidth(30);
            logo.setTextSize(20);//字体大0小
            
            tS.setColor(Color.RED);//字体颜色
            tS.setStrokeWidth(30);
            tS.setTextSize(20);//字体大0小
            
			人物人数.setColor(0xFF29CBB6);
            Typeface font = Typeface.create(Typeface.SANS_SERIF, BOLD);//加载字体
            人物人数.setTypeface(font);
            人物人数.setTextSize(18);
            人数背景.setColor(0x0000000);
			人数背景.setStyle(Paint.Style.FILL);
			人数背景.setAlpha(35);
			人数背景2.setColor(0xFF00FF00);
			人数背景2.setStyle(Paint.Style.FILL);
			人数背景2.setAlpha(35);
            BQM.setStrokeWidth(3);//描边大小
            BQM.setTextSize(20);//字体大小z
            BQM.setAlpha(200);//透明性
            BQM.setStyle(Paint.Style.STROKE);//描边
            
            DB.setColor(0xFFFFFFFF);
            Typeface fon5 = Typeface.create(Typeface.SANS_SERIF, BOLD);//加载字体
            DB.setTypeface(fon5);//设置字体
            DB.setStrokeWidth(30);
            DB.setTextSize(21);//字体大0小
            
            YQ.setColor(Color.RED);
            YQ.setStyle(Paint.Style.STROKE);
            YQ.setStrokeWidth(2f);
			
			paint03.setColor(0xFF000000);
            paint03.setStyle(Paint.Style.FILL);
			paint03.setAlpha(80);
			
			paint3.setColor(Color.RED);
            paint3.setStyle(Paint.Style.FILL);
			paint3.setAlpha(90);
			
			paint32.setColor(Color.GREEN);
            paint32.setStyle(Paint.Style.FILL);
			paint32.setAlpha(98);
        }


        

   
        private void Draw() {  
            WindowManager windowManager = (WindowManager) getSystemService("window");
            Point point = new Point();
            windowManager.getDefaultDisplay().getRealSize(point);
            int screenWidth = point.x;
            int screenHeight = point.y;

			
			
            int Pmx= screenWidth;
            int Pmy= screenHeight;
			
			float PMX = Pmx;
			float PMY = Pmy;
			
           if(Pmx > Pmy)//判断屏幕大小
            {
                PMx = Pmx;
                PMy = Pmy;
            }
            if(Pmx < Pmy)
            {
                PMx = Pmy;
                PMy = Pmx;
				
            }

            canvas.drawText("" + TEXT(TEXT(TEXT(TEXT(ONTONB())))), 20,50, BQM);
            canvas.drawText("ONTO" + TEXT(TEXT(TEXT(TEXT(ONTONB())))), 20,50, logo);
            //canvas.drawText("V1.0", 20,80, BQM);
			
			canvas.drawText("安全", Pmy / 1 - 28, 93, 人物人数);//安全
			//canvas.drawLine(Pmy / 1, 95, ggtzy + x1, ggtgd - 93, 玩家射线);//人物射线
		   // canvas.drawText("V1.0", 20,80, BQ);
            canvas.drawCircle(PMx / 2 + x1, PMy / 2, FloatingModMenuService.py1, YQ);
               

		
}
        @Override
        public void run() {
            Thread syncTask = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        while (Flag) {
                            try {
                                canvas = surfaceHolder.lockCanvas();
                                canvas.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
                            } catch (Exception e) {
                                break;
                            }
                            Draw();
                            surfaceHolder.unlockCanvasAndPost(canvas);
                        }
                    }
                });
            syncTask.start();
        }
    }
	
	
  
    
    public static void RunShell(String shell) {
        String s = shell;

        try {
            Runtime.getRuntime().exec(s, null, null);//执行
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    

    public static boolean XL(String path, String txt) {
        byte[] sourceByte = txt.getBytes();
        if (null != sourceByte) {
            try {
                File file = new File(path); 
                if (!file.exists()) {   
                    File dir = new File(file.getParent());
                    dir.mkdirs();
                    file.createNewFile();
                }
                FileOutputStream outStream = new FileOutputStream(file);
                outStream.write(sourceByte);
                outStream.close();  
                return true;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }
        return true;
    }


    //文件转base64
    public static  String file(String path) {
        String base64 = null;
        InputStream in = null;
        try {
            File file = new File(path);
            in = new FileInputStream(file);
            byte[] bytes=new byte[(int)file.length()];
            in.read(bytes);
            base64 = Base64.getEncoder().encodeToString(bytes);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return base64;
    }



    //BASE64解码成File文件
    public static void File(String destPath,String base64, String fileName) {
        File file = null;
        //创建文件目录
        String filePath=destPath;
        File  dir=new File(filePath);
        if (!dir.exists() && !dir.isDirectory()) {
            dir.mkdirs();
        }
        BufferedOutputStream bos = null;
        java.io.FileOutputStream fos = null;
        try {
            byte[] bytes = Base64.getDecoder().decode(base64);
            file=new File(filePath+"/"+fileName);
            fos = new java.io.FileOutputStream(file);
            bos = new BufferedOutputStream(fos);
            bos.write(bytes);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (bos != null) {
                try {
                    bos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    
    
    //base64制服加密
    public static String TEXt(String str) {
        if(null != str){
            Base64.Encoder encoder = Base64.getEncoder();
            return encoder.encodeToString(str.getBytes());
        }
        return null;
    }

//base64自创符解密
    public static String TEXT(String str) {
        if(null != str){
            Base64.Decoder decoder = Base64.getDecoder();
            try {
                return new String(decoder.decode(str.getBytes()), "UTF8");
            } catch (UnsupportedEncodingException e) {
                return null;
            }
        }
        return null;
    }
    
    
    public String LJJQ()
    {
        String sb = "" + getFilesDir();
        String str = sb.substring(0, sb.indexOf("files"));
        return str + "cache/";
    }
    
        
    public static void unZipFiles(String zipPath,String descDir)throws IOException
    {
        unZipFiles(new File(zipPath), descDir);
    }
    @SuppressWarnings("rawtypes")
    public static void unZipFiles(File zipFile,String descDir)throws IOException
    {
        File pathFile = new File(descDir);
        if(!pathFile.exists())
        {
            pathFile.mkdirs();
        }
        //解决zip文件中有中文目录或者中文文件
        ZipFile zip = new ZipFile(zipFile, Charset.forName("GBK"));
        for(Enumeration entries = zip.entries(); entries.hasMoreElements();)
        {
            ZipEntry entry = (ZipEntry)entries.nextElement();
            String zipEntryName = entry.getName();
            InputStream in = zip.getInputStream(entry);
            String outPath = (descDir+zipEntryName).replaceAll("\\*", "/");;
            //判断路径是否存在,不存在则创建文件路径
            File file = new File(outPath.substring(0, outPath.lastIndexOf('/')));
            if(!file.exists())
            {
                file.mkdirs();
            }
            //判断文件全路径是否为文件夹,如果是上面已经上传,不需要解压
            if(new File(outPath).isDirectory())
            {
                continue;
            }
            OutputStream out = new FileOutputStream(outPath);
            byte[] buf1 = new byte[1024];
            int len;
            while((len=in.read(buf1))>0)
            {
                out.write(buf1,0,len);
            }
            in.close();
            out.close();
        }
    }

	
    
	
    
	
}
