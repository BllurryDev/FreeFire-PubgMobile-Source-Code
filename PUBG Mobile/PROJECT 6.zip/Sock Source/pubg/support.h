#include "includes.h"

#if defined(__arm__)
int process_vm_readv_syscall = 376;
int process_vm_writev_syscall = 377;
#elif defined(__aarch64__)
int process_vm_readv_syscall = 270;
int process_vm_writev_syscall = 271;
#elif defined(__i386__)
int process_vm_readv_syscall = 347;
int process_vm_writev_syscall = 348;
#else
int process_vm_readv_syscall = 310;
int process_vm_writev_syscall = 311;
#endif

#define LEN sizeof(struct MAPS)

   
    
//deta
int height=1080;
int width=2340;
int pid=0;
int isBeta,nByte;
float mx=0,my=0,mz=0;

struct MAPS
{
long int fAddr;
long int lAddr;
struct MAPS *next;
};
typedef struct MAPS *PMAPS; 

   

int ifRun(){
    FILE *file;
  
    if (file = fopen("/sdcard/temp/on", "r")){
        fclose(file);
        return 1;
    }
    return 0;
}

int ifVech(){
    FILE *file;
    if (file = fopen("/sdcard/temp/vechon", "r")){
        fclose(file);
        return 1;
    }
    return 0;
}



//Syscall Implementation of process_vm_readv


ssize_t process_v(pid_t __pid,   struct iovec* __local_iov, unsigned long __local_iov_count, struct iovec* __remote_iov, unsigned long __remote_iov_count, unsigned long __flags) {
	return syscall(process_vm_readv_syscall, __pid, __local_iov, __local_iov_count, __remote_iov, __remote_iov_count, __flags);
}


int pvm(uintptr_t address, void* buffer,int size) {
	struct iovec local[1];
	struct iovec remote[1];

	local[0].iov_base = (void*)buffer;
	local[0].iov_len = size;
	remote[0].iov_base = (void*)address;
	remote[0].iov_len = size;


	ssize_t bytes = process_v(pid, local, 1, remote, 1, 0);
//ssize_t bytes = process_vm_readv(pid, local, 1, remote, 1, 0);
	return bytes == size;
}


uintptr_t getBase(){
    FILE *fp;
    uintptr_t addr = 0;
    char filename[32], buffer[1024];
    snprintf(filename, sizeof(filename), "/proc/%d/maps", pid);
    fp = fopen(filename, "rt");
    if (fp != NULL) {
        while (fgets(buffer, sizeof(buffer), fp)) {
            if (strstr(buffer, "libUE4.so")) {
                addr = (uintptr_t)strtoul(buffer, NULL, 16);
                break;
            }
        }
        fclose(fp);
    }
    return addr;
}





char** explode(char* a_str, const char a_delim)
{
    char** result    = 0;
    size_t count     = 0;
    char* tmp        = a_str;
    char* last_comma = 0;
    char delim[2];
    delim[0] = a_delim;
    delim[1] = 0;

    while (*tmp)
    {
        if (a_delim == *tmp)
        {
            count++;
            last_comma = tmp;
        }
        tmp++;
    }
    count += last_comma < (a_str + strlen(a_str) - 1);

    count++;

    result = malloc(sizeof(char*) * count);

    if (result)
    {
        size_t idx  = 0;
        char* token = strtok(a_str, delim);

        while (token)
        {
            assert(idx < count);
            *(result + idx++) = strdup(token);
            token = strtok(0, delim);
        }
        assert(idx == count - 1);
        *(result + idx) = 0;
    }

    return result;
}





/*

void dump(int pid,int faddr,long tby,char *name){
//printf("        p:%d-%X\n",pid,faddr);

	//	;
			struct iovec local[2];
			struct iovec remote[1];
			char buf1[999999];
			local[0].iov_base = buf1;
			local[0].iov_len = 999999;
			char buf2[20];
			local[1].iov_base = buf2;
			local[1].iov_len = 20;
			remote[0].iov_base = (void *)faddr;
			remote[0].iov_len = tby;
		process_vm_readv(pid, local, 2, remote, 1, 0);
		
		FILE *fp = fopen(name,"w");
fwrite(&buf1[0],sizeof(unsigned char),1,fp);
fclose(fp);
			for (int i =1; i<tby; i++)
			{
FILE *fp = fopen(name,"a");
fwrite(&buf1[i],sizeof(unsigned char),1,fp);
fclose(fp);
			//	break;
		}
		
}*/





int getPid(char * name){
DIR *dir=NULL;
struct dirent *ptr=NULL;
FILE *fp=NULL;
char filepath[256];
char filetext[128];
dir = opendir("/proc");
if (NULL != dir)
{
while ((ptr = readdir(dir)) != NULL)
{
if ((strcmp(ptr->d_name, ".") == 0) || (strcmp(ptr->d_name, "..") == 0))
continue;
if (ptr->d_type != DT_DIR)
continue;
sprintf(filepath, "/proc/%s/cmdline", ptr->d_name);
fp = fopen(filepath, "r");
if (NULL != fp)
{
fgets(filetext,sizeof(filetext),fp);


if (strcmp(filetext,name)==0)
{
fclose(fp);
break;
}
fclose(fp);
}
}
}
if (readdir(dir) == NULL)
{
closedir(dir);
return 0;
}
closedir(dir);
return atoi(ptr->d_name);
}





int substring(char *source, int from, int n, char * target){
    int length,i;
    
    for(length=0;source[length]!='\0';length++);
     
    if(from>length){
        //printf("Starting index is invalid.\n");
        return 0;
    }
     
    if((from+n)>length){
        n=(length-from);
    }
    for(i=0;i<n;i++){
        target[i]=source[from+i];
    }
    target[i]='\0'; //assign null at last
     
    return 1;    
}


uintptr_t getA(uintptr_t address) {
	struct iovec local[1];
	struct iovec remote[1];
	uintptr_t buff[1];
	local[0].iov_base =buff ;
	local[0].iov_len = sizeof(buff);
	remote[0].iov_base = (void*)address;
	remote[0].iov_len = sizeof(address);

	if (pid < 0) {
		return 0;
	}
	ssize_t bytes = process_v(pid, local, 1, remote, 1, 0);
//ssize_t bytes = process_vm_readv(pid, local, 1, remote, 1, 0);
	return buff[0];
}


float getDistance(float mxyz[],float exyz[]){
return sqrt ((mxyz[0]-exyz[0])*(mxyz[0]-exyz[0])+(mxyz[1]-exyz[1])*(mxyz[1]-exyz[1])+(mxyz[2]-exyz[2])*(mxyz[2]-exyz[2]))/100;
	
}
void w2s(float *am0,float* am1,float vMat[],float exyz[],int * isBack){

			float screenX = (exyz[0]*  vMat[0]) + (exyz[1]*  vMat[4]) + (exyz[2]* vMat[8]) + vMat[12];
			float screenY = (exyz[0]*  vMat[1]) + (exyz[1]*  vMat[5]) + (exyz[2]* vMat[9]) + vMat[13];
			float screenZ = (exyz[0]*  vMat[2]) + (exyz[1]*  vMat[6]) + (exyz[2]* vMat[10]) + vMat[14];
			float screenW = (exyz[0]*  vMat[3]) + (exyz[1]*  vMat[7]) + (exyz[2]* vMat[11]) + vMat[15];
			
			float ndcX = width / 2;
			float ndcY = height / 2;
			float ndcZ = screenZ / screenW;
			 *am1 = ndcX + (ndcX * screenX / screenW);
			*am0 = ndcY - (ndcY * screenY / screenW);
if(screenW<0.01f)
*isBack=1;

	
}



