#include "support.h"
#include "socket.h"
#include "init.h"

uintptr_t getEntityAddr(uintptr_t base);
char* getNameByte(uintptr_t address);
int main(){
	isBeta=0;
	int sText[400];
	if(isBeta==0){
		if(!Create()){
		perror("Creation Failed");
		return 0;
	}
	
	if(!Connect()){
		perror("Connection Failed");
		return 0;
	}
//	exit(-1);

char msg1[]="getConfig";
	sendit((void*)&msg1,strlen(msg1));
	nByte=recieve((void*)&sText);
if(nByte<5){
	Close();
	return 0;
}

int no,hei,wid,ifVe;
sscanf(sText, "%d-%d-%d-%d", &hei,&wid,&no,&ifVe);
height =hei;
width=wid;
isVehicle=ifVe;

//printf("\n%s",sText);
//return 0;
//return 0;
if(no==1)
version="com.tencent.ig";
else if(no==2)
version="com.pubg.krmobile";
else if(no==3)
version="com.vng.pubgmobile";
else
version="com.rekoo.pubgm";

} //betaend


pid=getPid(version);
	if (pid == 0)
	{
	printf("\nGame is not running");
	Close();
	return 0;
	}
	printf("\n Game Pid: %d",pid);
//	return 0;
	uintptr_t base = getBase();
	uintptr_t vMatrix,cLoc,fovPntr;
	if(!getMatrix(base,&vMatrix,&cLoc,&fovPntr)){
		puts("\nMatrix Not Found");
		return 0;
	}
	printf("\nvMatrix: %X",cLoc);

	
	
	
	//looooooooooooooop
	uintptr_t enAddr=0;
	float xy0,xy1;
	float xyz[3];
	int isBack=0,type=69;
	int changed=1;
	int myteamID=101;
	while(connected  || isBeta){
		char fulltext[0x4000]="/";
	
		//my Location + fov + vMatrix
float ml[3];
		pvm(cLoc,(void*)ml,sizeof(ml));
		if((ml[1]==311.242523193359375f || ml[1]==0) && isBeta==0){
			changed=1;
			/*strcpy(fulltext,"lobby");
			sendit((void*)&fulltext,strlen(fulltext));
	nByte=recieve((void*)&fulltext);
if(nByte<5){
	Close();
	return 0;
}*/
		//puts("\nlobby");
		usleep(1000000);
		continue;
		}
	float fovP[1];
		pvm(fovPntr,fovP,4);
	float fov=fovP[0];
	float vMat[16];
	pvm(vMatrix,vMat,64);
	//end
	
	
	//enList
	if(changed==1){
	enAddr=getEntityAddr(base);
	changed==0;
	}
	
	
	unsigned int bbuff[2];
	pvm(enAddr,bbuff,sizeof(bbuff));
//			printf("j,jbm jbm%dj",buff[1]);
//	return 0;
	

	//Entity Loop
	if(bbuff[1]<0 || bbuff[1]>1024){
		//puts("\nWrong Entity Address");
		changed =1;
	  continue;
	}
		if(isBeta)
		printf("\nEntity Size: %d",bbuff[1]);
				/*type
			0=behind enemy
	1=person
	2=bot
	3=vechile
	4=item
	*/
		
		int tot=0,teamchk=1;
	for(int i=0;i<bbuff[1];i++){
		uintptr_t pBase=getA(bbuff[0]+i*4);
		if(pBase==0xffffffff)
		continue;
		
		
		char cont[300]="";
		if(pBase<0x1000000 && pBase>-100)
		continue;
		
		
		
		
			int  id=getA(getA(getA(pBase+0xc)+0xA8)+0x2F4);
	if(id==0){
		
		int teambuff[18];
		pvm(pBase + 0x5f8, teambuff, sizeof(teambuff));

			//continue;
			float health=-0.1f;
			
			
			//Human and Vechile
			if (teambuff[17] == 0x40400000){
			type = 3;
			}else if (teambuff[13] == 0 || teambuff[13] == 1) {
				/*if(teambuff[1]==0)
				continue;*/
		type = 1;
				 if(teambuff[12] != 0xffffffff)
				type=2;
				
		}else{
			continue;
		}
	
		if(type==1 || type==2){//Player
	char *name="";
		int teamID = teambuff[10];
		if(teamID<1 || teamID>100)
		continue;
		float health = 69.0f;
	float healthn[2];
	
	pvm(pBase+0x830,healthn,sizeof(healthn));
	if(healthn[1]<0.0f || healthn[1]>500.0f || healthn[0]<0.0f || healthn[0]>500.0f)
	continue;
	health=healthn[0]/healthn[1]*100;
	uintptr_t xyzA =getA(pBase+0x25e0);
	pvm(xyzA+0xfc,xyz,sizeof(xyz));
	if(xyz[0]==0 || xyz[1]==0 || xyz[2]==0)
		continue;
		
		int humanChk=getA(xyzA+132);
		if(!(humanChk==0x2A050C23 || humanChk==0x2A050CA3))
	continue;
	

			
	tot++;
	if(getA(pBase+0xe8)==0x102){
	myteamID=teamID;
	continue;	
	}
	else if(myteamID==teamID)
		continue;
		
		float distance =getDistance(ml,xyz);
		if(distance<1.0f)
		continue ;
		isBack=0;
w2s(&xy0,&xy1,vMat,xyz,&isBack);
	if(isBack==1)
	type=0;
	//continue;
			name = getNameByte(teambuff[0]);
		if (strlen(name) < 4)
			continue;
		sprintf(cont,"%d,%0.2f,%0.2f,%0.2f,%0.2f,%0.2f,%s/",type,xy1,xy0,distance,health,fov,name);
	strcat(fulltext,cont);
	
//	printf("\n%s",cont);
	if(isBeta==1)
	printf("\nEnemy[%X]: %0.2f,%0.2f,%0.2f,%s,%x",pBase+0x25e0,xy1,xy0,distance,name,getA(xyzA+36));
	
		}else{ //Vehicles
		
		uintptr_t xyzA =getA(pBase+0x138);
	short int vechChk=getA(xyzA+150);
	if(!(vechChk==0x2207))
	continue;
		pvm(xyzA+0xfc,xyz,sizeof(xyz));
		if(xyz[0]==0 || xyz[1]==0 || xyz[2]==0)
		continue;
		isBack=0;
		w2s(&xy0,&xy1,vMat,xyz,&isBack);
	if(isBack==1 && isBeta==0)
	continue;
	float distance =getDistance(ml,xyz);
	
		sprintf(cont,"3,%0.2f,%0.2f,%0.2f,0,0,%X/",xy1,xy0,distance,vechChk);
	strcat(fulltext,cont);
	
	if(isBeta==1)
	printf("\nVehicle: %0.2f,%0.2f,%0.2f",xy1,xy0,distance);
		}
		
		
		
		}else{ //ITEMS
			type =4;
	
	
	pvm(getA(pBase+0x138)+0x150,xyz,sizeof(xyz));
	
	if(xyz[0]==0 || xyz[1]==0 || xyz[2]==0)
	continue;
	
	
	isBack=0;
	w2s(&xy0,&xy1,vMat,xyz,&isBack);
	if(isBack==1 && isBeta==0)
	continue;
	sprintf(cont,"%d,%0.2f,%0.2f,0,0,0,%d/",type,xy1,xy0,id);
	strcat(fulltext,cont);
	
if (isBeta==1)
	printf("\n%X-%x | %0.2f %0.2f %0.2f",pBase,id,xy0,xy1,xyz[2]);
		}
	}
	
//	printf("\n%d",strlen(fulltext));
	
if(isBeta==0){
	if(strlen(fulltext)<5)
	strcpy(fulltext,"clear");
			sendit((void*)&fulltext,strlen(fulltext));
	nByte=recieve((void*)&sText);
if(nByte<2){
	Close();
	return 0;
}
}
//Delay period 1000=1ms
usleep(25000);



		//end of while
		if(isBeta==1)
		break;
		}
	
	Close();
	puts("\nCompleted");
}








int getMatrix(uintptr_t base,uintptr_t* va,uintptr_t* cl,uintptr_t *fov){
	uintptr_t vaddr=getA(getA(base+0x702BC70)+0x68);
	if(vaddr==0)
	return 0;
	*cl=vaddr+0x6C0;
	*va=vaddr+0x6D0;
	*fov=vaddr+0x5D0;
	return 1;
}

uintptr_t getEntityAddr(uintptr_t base){
		return getA(getA(base+0x6BC94E8)+0x20)+0x70;
}

char* getNameByte(uintptr_t address){
char static lj[20];
unsigned short int nameI[20];
		pvm(address,nameI,sizeof(nameI));
		char s[50];
    strcpy(lj,"");
    int am=0;
		for(int i=0;i<20;i++){
			if(nameI[i]==0)
		break;
		
			sprintf(s,"%d:",nameI[i]);
			//printf("%x ",nameI[i]);
			
	strcat(lj,s);
		}
		


		return lj;
}