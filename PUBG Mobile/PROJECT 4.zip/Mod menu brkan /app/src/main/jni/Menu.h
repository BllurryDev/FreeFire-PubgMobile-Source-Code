
bool titleValid = false, headingValid = false, iconValid = false;

void *antiLeech(void *) {
    sleep(15);
    if (!titleValid || !headingValid || !iconValid) {
        //Bad function to make it crash
        int *p = 0;
        *p = 0;
    }
    return NULL;
}

extern "C" {
JNIEXPORT jstring
JNICALL
Java_zeed_hacker_modmenu_FloatingModMenuService_Title(JNIEnv *env, jobject thiz) {
    titleValid = true;

    //Html is supported
    return env->NewStringUTF(OBFUSCATE("<b>Zeed VIP Mod Apk V1</b>"));
}

JNIEXPORT jstring
JNICALL
Java_zeed_hacker_modmenu_FloatingModMenuService_Heading(JNIEnv *env, jobject thiz) {
    headingValid = true;

    //It will autoscroll if the text is too long
    //Html is supported
    return env->NewStringUTF(OBFUSCATE("<b><marquee><p style=\"font-size:30\">"
                                       "<p style=\"color:green;\">Created by Zeed Hacker</p> | "
                                       "Telegram: @Zeed_Hacker1</p>"
                                       "</marquee></b>"));
    // return env->NewStringUTF(OBFUSCATE("Put your website or notes here"));
}

JNIEXPORT jstring
JNICALL
Java_zeed_hacker_modmenu_FloatingModMenuService_Icon(JNIEnv *env, jobject thiz) {
    iconValid = true;

    //Use https://www.base64encode.org/ to encode your image to base64
    return env->NewStringUTF(
            OBFUSCATE("iVBORw0KGgoAAAANSUhEUgAAAHkAAAB4CAYAAADWpl3sAAAABHNCSVQICAgIfAhkiAAAEYNJREFUeJzt3XuUXVV9B/DP3JnJg5AHBJBAMIovTEVQQFIQAUVAXAhKldYuYrSu1hdKX1qriBWfqOBCqatS1mpBpJbWR3xVakW0xidKrEBEDPJQwiOBvGcyM3f3j9+5mZsz99y5k5m5cya5v7V+Kzdz79ln7/3dj9/+vXaX3acFOBbPxZNxWMYLUBlHuR1iM36H+3EfVmMVHkYaa2FdY/z9QrwKp+NI7DubmSfT+zx6nkXP4VQOomvf3Sh8b6eELXiY6loGb2fwxwx+h/7t9OFO3IIbcC+qrZTbKg4LcQGWYwnmnMmMP6brZehFD7rFFK5N4w7IY6PaFK1mPIRBDGAlPs+Ob7Ad63EjPoPfahHsIlqIi/AzbMDgeVRvIW0m9ZOqpNThSeVq1tebSbeQzgtQN+E3+DCeaDe3yB68Q+wLg0dQvZG0hTRQgobvrTyQYXAj6YhhsD+JA4uALFpR5+GjOBcHLKdyJfYRS3Oe7sK38ROswQNCchjXGrIXUgVzsRhH4Di8EE9v8NsBbMNbcW1s5d/F27BWC13fLdb6DaheQtqq8bJ8PelM0lzSbFIvqULqIunwbnFX1oe9WZ/Ozfr4+gb9X82wuSSe7cPXsWg0gOFv8BCql5G2Nyh8JemErBLdJeiYPZ27s74+Iev7PB7bSZcNA/1JcYwtpHNwD4YuIfU1KPAi0j5itE114/c2rmR9f1EDXPrsnNGbcSHmNAJ4f7GtDiw3cgb/XiwbM0rQ2L2dZ2RY/N7IGb08fvMgjtJA4n4HHjuC6pYGAC/TWZrLxN0ZJnmgt9gpdX9Cbtk+BLdj6AtGClmn6yzPZeRKhk09VlXSF+L7R3C0utn8Hjx+HtUdRu7BnRlcXu42co/eYafC5B+xXw3kr6N/Ve7HK3X24OnAM4yUulfFd7eLVdoS3HMm1bwm67gSNKDDrfFxOewGSGeyAydVhFJl7gV09Rimz+FWHZoudKvArEY9uCAUlC+q4KhZzDwv99A1OmrJ6URVgVk9nYfZHFnBwafSPaPuy7uE0bJD04tuEdjVaAZO5uAKDj2RnnpLxbeELbND04uGBHY16sKJHFjBE44Ko8ROWtXOmnVoQimP3dEZyLOemjM5/rJ9derQbtISIVzlKY/dU5lXQdeiHMj3TVbNOjQhdCwO0HhLzWO3iEqFMFTX08ZJqFiHxk89OB7PEZ4BjRw48tjNzZ4b4R7SOTqVh7qEwDQo3HSeieuEPXGwwe/z2HUpALlD5aF9BXBvErbDDwhf3NTi8ztB7lB5aYfwAFiG14vluFWAa9QBuaQ0SygzXo6zhLH/8d0sqwNySWmucLY7CW/Hz8dRVmlB3hcHC7fTWcJDrUdj+WGqZIqiZTOJOu0QdU6G3W0fF0FORVQR7pbvETN4OX6ksZDVKpUS5Apehg8KB/CK4Y4aCxWB0OqgGOvel6eqqPNQxtvxMeFOWUQLcIUwDf6FcKaeCBXz/SlnizTF/ETSTaQh4c5S43w9R+NqAY/3+bHyAOnXpDcLb8tGbe4lPYd0M+kB0ttIs3az/xrgWT6Q3yzifsYKahm5mgF8DmlOQXtrvlo/IW0ivZu0YBz9V3qQDyfdZ/oH0tXq/zPSH2ruRnUq6ZfCd/py0n7j7MNSg9xL+oRYpqcapN3lWt0HSP9DWqyxp2sXaSbpDNJjpMdJXxOREuPtx9KCXCG9PGvwVAM1Ht6WAfwl0lGK48Lmk/6StFF4V36V9KQJ6svSgnywCMccLAFQ4+Eq6Z9JRyj2VV9A+gfSOjHzf0p6oYlzfS4lyBUR3rHB9N6Lq6SPZSA2ArgG4tVCwKqSHhJC10S6PpcS5ENFBH27AR4SS2ttH92dVaT27BbSR0kLC9rYRXqCWJb7s3c9TDrFxAcv5OtYCmXICpygWEmxXuSzGMx+k3Lf5/9fRPXlJ8MaqYpQXBwkDPKtKl1qOT36cWXG6wve+xxcjBcL0+H9uBTfM/n+dFMO8jPwhiYVSUJ3W6T5aRXgGtWATnX/dgmQ/9PYVaSPCRXkjYoNCM/H+0XmgF4xED6RPdMuh8kpXa6vV3xk2kE6XxytuiaZbzD2XCgPkM7N6lfUvjOy3w0Y3o6uFhkEJqtPG+A5dSCfKwSP/PuHSGtJryD1THIdFghhqV8MqlbA3UG6jXR2k/rNyup/bx24O8RgKlJt7nEgH0r6isaz+C7SK02MYqAZzya9nfSo1vXaQ6TvkE5qAnAv6Q2kX9W1r18cERe3oW9LAXIX6XVCIs2/ex3pxDYAjPRWu8600cAdsjO1UlOJ+L2kB+06gG8mHak9SXNKAfIc0vdznTsklsDFo3TgRA2yV4kZ3KoKdSAD+IlNgJpB+rhI61BrWx/pHjFw2xXIXwqQ32VXIWdAnB+PasO7u0kniy1htBlczQbBFtI1YgYXAXyA2Ns35sq4l/QS7Q3kn3KQnydmUP37Pi+WsnaM9KWkb2tN8TGU1fW9QslRVL9DhMS82a4D526xYky28FgqkOcJYau+I64WmqB2ADxHHNn6jD6LNwjL0F8LY0JRmYcLc+K2XJkbhNwxFZkapgzkLtKrhSoviUxynyId2KaGzxdL7mhJX2vfrSO9RbF3RoV0POnHYlWoL3Mb6VLNz897JMiHkr4hlsDtYv8q0vNOxrs/nQFcBG6NB0g/EmfcZufZk0nfNVKB0icG72QqO0oL8gqxZ/WR/kqYFtvR4PmkDxopEDXi7aRbMwCb7aN/JE4C9VqslH3+V9JBUwjwlIJ8p9inXi2WwHYlWb2A9IjWzsK3kZ4/CsB/LrR0jQS3r5g4w/+0AnkG6QMic9wb7b4H4li5W9hpW1F2DIm99RjFR535Il/WQwXlrSIdqxwZgtsO8rlCD71CeyXNs0lrjK7s2C6OcE9SLOEfQPqQEBobAXyXsAuXJWthW0HeTxjSX6S9kuYLSD9vAeAtwjtyieIZuEQYFTYWALxO7OFlylrYVpAXC0VBOztgiZDiR1N2DGUAz24C8GLS5+yqpqzn9aSXlQzgtoNcs9W2q3GLSJ81ul34ftLfa24EOZL0RWEebATwY6T3mNqjUilAbicvIl0rlCzNAF4rnAaLohkIQ/8qxfblPpEp/gklaPdeA/JCoYDIqxbzvI50luZKjrNJt2u+3F+TvbMMkvReAXLN8L++CcBD4ijVzNBfi0daq1hg6yf9h/GHsXRAHgNXhLLjd00AHhBLb7Mz8ByxhP++CcCDQqD7gxK0e68C+SwxQ4uAqYo80M9TfIRbSPo7xUqOGt8qQkvLchbeK0B+qQgJbXYWvl7oyIuAmU+6SkjKzQB+lHT0NAF4jwH5BGHDLQJ4K+kKzQWs/YVlqhau0qicqtB7nzuNAN4jQD6c9E3F0u9GYcZc1KSMZ4rz9GjS+AOkP9M+fXsHZKHN+qrmyo53iiW66HhzTFZGkRarxjtExH8zr5CJ5oWan9/3eJAXiONLkYJiG+lPNFdTLiKtVqzFqudLtcctuJ7fQdp3bwV5X9L7xP6Zr2uV9JsM4CIr1ywhYf+fka46ed4u4otntrF9NceGt0xQedMS5IuEtqoROLcJwaho35wjHOruNLpVqk+sFkva2LZuYan7onBT2itBXt4E4JvF0aaZnfoNwrm9FRfc72fltcuqNF8MqruFUmePzjTQiLtIpxnpy5zEjFwpzJhFR5te4Ymy2XA+sGYAPywk93YdlZ4sBmm/sFePJ6XTtAS5YjjtUR6cAdK/aR7NcKCwEo12REqG9/Tjm5Q30fxcEXKzTShizprg8qcFyEdqHOXQR7qS9BTFM25/4QywfhRwa/xrEeXQriX6OJE6Y6uYxZ8y8efwaQHyfxt5zNlB+tsMxGZpk76i2FUnz+vFnt+uo9Jpwu+s5sq7xuS475Ya5Lkip2ben3kD6WIRZtPouYrRPTnyvE2EwLTjqFQRS3K9hL+N9KZJel9pQV4oluL8DewPCF/nIjebbpED63tai5BI4rx9mYkVdprxOaQ76gCuCrPlYXsTyLNEOGve5XWNmAHNPD1PFcnOWp3B24Vnx0SdSZtxl5itd9v1jP6oOLtPVrRjKUFeLiII60G6w+jhKucbjmZoNQfYt4SP9WRL0vuQ3i/2/bwS5ksm17zeedVCB3C5fWB+tAqgr98lmKJd7ZpNcoVpIU8S+EsmOyAZ4p0jk3yjC4VTgKTub7SwNyJWvsmrqOGBLS8TLFM3iOCJj77RgBvk3YoSdb2XGQcNVtpMRJIt3EZAellwbkE8VeWjsL95OuIz2tCRDdQmB6yNjSJa8VA2qyz8KLszZsKQD4B5rbufcokGeSfpgBvC0D7DqhqSpaSmeJmKVWsgTU872aL/0TxYeSvqw4yL1fCGHtULrk3932tIuLxI3dxxi+z/cakXfykYJnno534WzMHMO7ksjJWcWZ2d8GsTX7nE+x2JX7W/5zo5yb1ew9b8QZ4i6nRvW4GV8zNfdStxXkw/BenCI6bD2uwuWKLwE9Ulxdd5q4Omis9JLsfT0i0Wm3uIaoO+PUYjldRg4C2fOPKb7qlmjb50ztbbZtWa4XCKFjo+E0wG/WPJboJGHoHy3PRzOeqBthmvFo8sG12utG1ADPyQe5Iuy6fUIZcb/mnhw1M+MdxnYGLiNvFSrXdgE8JSD3CIN4LTphtUhe1kyLdYGIR5rOF44kMUAv0/7Q1raDfL7QPw+KxKOnFDS6Fub6NmNLh1hm/rFwDmgnwG0H+SRh+B8S6sRnKJ7B+4iUDdP9HooabxWeKVMRoN42kJ8i3Fu2CD/nxYrPwPNIl2gezTCduCoG9ZIpALhtIB8iXHQeFBL1vCYAHypCWorUgNORtwrd+lTFL086yIuE/9KjIlqwyPOhQnq28Fbs05qz3XThm7T3yDQayBOqDNkfHxHX4l6EfxHXyTaiXiwVCoKPiytlB7K/D4q7hndkn2dnn5ORF4W0Qo0uDxnv8/nve8Udz13iUpEi5c5UUJeYyYvzfxwrzcA78ad4n7gppX+UZ3oNa50aqRgVfFdWqg2cfmMbRJNVjxpN2Ex+o5jBF+PLRgeYmLkDE1WBDjWlce/JbxdRCqeafmGeeyJP6J7cI25nOx+nY62psbJ0qDntNsjdOFFcT/c63G1q96EOFdNugVy7e/A4fBp36ABcZuphpATb6NLLejpCXFx5Ax4UhvMOlYMa2bsr2Lwlh9O8Fgr6dx2Ay0h57DazpYL163Ly0mLN6VfYoANwGSmP3UM8WsHD9+RAXjpKQR0JuryUx24tj1TwyOocbsvaV6cOTTDlsftFBvKaVaEa3kkvbl+dOjTBlMfuB7G7etZcfldvARoUUQw6PK14mV0D96zeedeby0gjWbufvLdWrkbqHJ6tD0ohWGfdlhJfdt4pcVYc373+vCUraTXmt0AaxD5aGlArN6upZvY3Pt/8/sZu1qqvWK7etLsAR1uDW+3q5GidUxaV+gTqvZjUtXsLH+h/3iPqepbkCHm/MKI7MsvJbrcKAcHdLLnTcxVP/jrTpCWJl5mZGXq9zEll6Ot+sWjdBWvuZYHs37Wt0lLpee6gZ1eFdemmFTj1WVdAzv1kQ7PbvCBy7MLdtDpF/pzOgy8bIMk3wQwltjmV5sFK+pBTNYeQV9eaA36ezRZeAVGRZ5gC/nB8JI2CjKdgQ9bSa3/hMDKVfQVhGl11m+289LFV9w9hnW9fB8Y/ARqOCw2XzyCjbnC+wXIahX6Szh7eBlWV9v1DhX2eWs7OW5wgF2zLRgJhdeGMJYNV94v1g2fiTimF6Rjbb5ynv7WZm5K+u7pVlffijr200F4FYZvJAPz4oY+BGSdI1acWme08PRx/KaS3nlaczPPzck1GaD2edarTs0dqplM+gW626PhugNfov/upirf8j3hXl/3F3eg/324ZjX86nVrE8NZnaHJ523reaG13HaHA7WOEVJw4EzFurG3NnMPYdnn8+Z53BMFwvFDJ8nUntMl6CHslK/0DlvwsYqq7/KNz/LT2+MFCWbjCEu4f8BtY1XopLkCl0AAAAASUVORK5CYII="));
}

JNIEXPORT jstring
JNICALL
Java_zeed_hacker_modmenu_FloatingModMenuService_IconWebViewData(JNIEnv *env, jobject thiz) {
    iconValid = true;
    //WebView support GIF animation. Upload your image or GIF on imgur.com or other sites

    // From internet (Requires android.permission.INTERNET)
    // return env->NewStringUTF(OBFUSCATE_KEY("https://i.imgur.com/SujJ85j.gif", 'd'));

    // From assets folder: (Requires android.permission.INTERNET)
    // return env->NewStringUTF(OBFUSCATE_KEY("file:///android_asset/example.gif", 'r');

    // Base64 html:
    // return env->NewStringUTF("data:image/png;base64, <encoded base64 here>");

    // To disable it, return NULL. It will use normal image above:
    // return NULL

    //return env->NewStringUTF(OBFUSCATE_KEY("https://i.imgur.com/SujJ85j.gif", 'u'));
    return NULL;
}


JNIEXPORT jobjectArray
JNICALL
Java_zeed_hacker_modmenu_FloatingModMenuService_getFeatureList(JNIEnv *env, jobject activityObject) {
    jobjectArray ret;
    // Note: Do not translate the first text

    // Usage:
    // Category_(text)
    // Toggle_(feature name)
    // SeekBar_(feature name)_(min value)_(max value)
    // Spinner_(feature name)_(Items e.g. item1,item2,item3)
    // Button_(feature name)
    // ButtonLink_(feature name)_(URL/Link here)
    // ButtonOnOff_(feature name)
    // InputValue_(feature name)
    // CheckBox_(feature name)
    // RadioButton_(feature name)_(Items e.g. radio1,radio2,radio3)
    // RichTextView_(Text with limited HTML support)
    // RichWebView_(Full HTML support)

    // Learn more about HTML https://www.w3schools.com/

    const char *features[] = {
            OBFUSCATE("RadioButton_FPS_30 FPS,40 FPS,60 FPS,90 FPS"),
            OBFUSCATE("Category_Player Visual"),
            OBFUSCATE("CheckBox_360 Alert"),
            OBFUSCATE("CheckBox_Line"),
            OBFUSCATE("CheckBox_Box"),
            OBFUSCATE("CheckBox_Skeleton"),
            OBFUSCATE("CheckBox_Name"),
            OBFUSCATE("CheckBox_Health"),
            OBFUSCATE("CheckBox_Distance"),
            OBFUSCATE("RichTextView_<font color='#cd75ff'>Info Location:</font>"),
            OBFUSCATE("RadioButton_Info Location_Above Head,Below Player,None"),
            OBFUSCATE("Category_Item Visual"),
            OBFUSCATE("RichTextView_<font color='#cd75ff'>Rifle:</font>"),
            OBFUSCATE("CheckBox_M16A4"),
            OBFUSCATE("CheckBox_Mk14"),
            OBFUSCATE("CheckBox_DP28"),
            OBFUSCATE("CheckBox_G36C"),
            OBFUSCATE("CheckBox_Mk47"),
            OBFUSCATE("CheckBox_Mutant"),
            OBFUSCATE("CheckBox_Groza"),
            OBFUSCATE("CheckBox_M762"),
            OBFUSCATE("CheckBox_Beryll"),
            OBFUSCATE("CheckBox_AKM"),
            OBFUSCATE("CheckBox_M249"),
            OBFUSCATE("CheckBox_AUG"),
            OBFUSCATE("CheckBox_QBZ"),
            OBFUSCATE("CheckBox_M416"),
            OBFUSCATE("CheckBox_SCAR"),
            OBFUSCATE("CheckBox_M249"),
            OBFUSCATE("RichTextView_<font color='#cd75ff'>Machine Gun</font>"),
            OBFUSCATE("CheckBox_UMP45"),
            OBFUSCATE("CheckBox_Thompson"),
            OBFUSCATE("CheckBox_Vector"),
            OBFUSCATE("CheckBox_MP5K"),
            OBFUSCATE("CheckBox_PP-19 Bizon"),
            OBFUSCATE("CheckBox_Uzi"),
            OBFUSCATE("RichTextView_<font color='#cd75ff'>Sniper</font>"),
            OBFUSCATE("CheckBox_AWM"),
            OBFUSCATE("CheckBox_Kar98k"),
            OBFUSCATE("CheckBox_SKS"),
            OBFUSCATE("CheckBox_SLR"),
            OBFUSCATE("CheckBox_QBU"),
            OBFUSCATE("CheckBox_Mini14"),
            OBFUSCATE("CheckBox_VSS"),
            OBFUSCATE("CheckBox_Win94"),
            OBFUSCATE("CheckBox_M24"),
            OBFUSCATE("RichTextView_<font color='#cd75ff'>Shotgun</font>"),
            OBFUSCATE("CheckBox_Sawed Off"),
            OBFUSCATE("CheckBox_DBS"),
            OBFUSCATE("CheckBox_S1897"),
            OBFUSCATE("CheckBox_S686"),
            OBFUSCATE("CheckBox_S12K"),
            OBFUSCATE("RichTextView_<font color='#cd75ff'>Pistol</font>"),
            OBFUSCATE("CheckBox_Flare Gun"),
            OBFUSCATE("CheckBox_P18C"),
            OBFUSCATE("CheckBox_P92"),
            OBFUSCATE("CheckBox_Desert Eagle"),
            OBFUSCATE("CheckBox_R14"),
            OBFUSCATE("CheckBox_P1911"),
            OBFUSCATE("CheckBox_Pistol"),
            OBFUSCATE("RichTextView_<font color='#cd75ff'>Ammo</font>"),
            OBFUSCATE("CheckBox_AWM"),
            OBFUSCATE("CheckBox_12 Gauge"),
            OBFUSCATE("CheckBox_.45 ACP"),
            OBFUSCATE("CheckBox_9mm"),
            OBFUSCATE("CheckBox_7.62mm"),
            OBFUSCATE("CheckBox_5.56mm"),
            OBFUSCATE("CheckBox_Scope"),
            OBFUSCATE("CheckBox_x2"),
            OBFUSCATE("CheckBox_x3"),
            OBFUSCATE("CheckBox_x4"),
            OBFUSCATE("CheckBox_x6"),
            OBFUSCATE("CheckBox_x8"),
            OBFUSCATE("CheckBox_Red Dot"),
            OBFUSCATE("CheckBox_Holo Sight"),
            OBFUSCATE("CheckBox_Canted Sight"),
            OBFUSCATE("RichTextView_<font color='#cd75ff'>Armor & Helmet</font>"),
            OBFUSCATE("CheckBox_Armor lvl 3"),
            OBFUSCATE("CheckBox_Armor lvl 2"),
            OBFUSCATE("CheckBox_Armor lvl 3"),
            OBFUSCATE("CheckBox_Helmet lvl 3"),
            OBFUSCATE("CheckBox_Helmet lvl 2"),
            OBFUSCATE("CheckBox_Helmet lvl 1"),
            OBFUSCATE("CheckBox_Bag lvl 3"),
            OBFUSCATE("CheckBox_Bag lvl 2"),
            OBFUSCATE("CheckBox_Bag lvl 1"),
            OBFUSCATE("RichTextView_<font color='#cd75ff'>Medic</font>"),
            OBFUSCATE("CheckBox_Medkit"),
            OBFUSCATE("CheckBox_First Aid Kit"),
            OBFUSCATE("CheckBox_Injection"),
            OBFUSCATE("CheckBox_Pain Killer"),
            OBFUSCATE("CheckBox_Drink"),
            OBFUSCATE("RichTextView_<font color='#cd75ff'>Other</font>"),
            OBFUSCATE("CheckBox_Weapon Attachments"),
            OBFUSCATE("CheckBox_All Items"),
            OBFUSCATE("Category_World Visual"),
            OBFUSCATE("CheckBox_Vehicle,Loot Box,Air Drop,Grenade Warning"),
            OBFUSCATE("Category_Aim Menu"),
            OBFUSCATE("CheckBox_Aimbot"),
			OBFUSCATE("RadioButton_Aim Location_Head,Body")
			OBFUSCATE("RadioButton_Aim Target_Shortest Distance,FOV")
			OBFUSCATE("SeekBar_FOV Size_1_500")
			OBFUSCATE("RadioButton_Aim Trigger_Nothing,Shooting,Scope")
			OBFUSCATE("CheckBox_Aim Knocked")
			OBFUSCATE("CheckBox_Visibiliity Check")
			OBFUSCATE("CheckBox_Smooth Aim (Recommended)")
            OBFUSCATE("SeekBar_Smoothness_0_5"),
            OBFUSCATE("Category_Memory Hack (BAN RISK!)"),
            OBFUSCATE("CheckBox_Bullet Tracking"),
            OBFUSCATE("CheckBox_Less Recoil"),
            OBFUSCATE("CheckBox_No Shake"),
            OBFUSCATE("CheckBox_Wide View"),
            OBFUSCATE("CheckBox_Magic Bullet"),
            OBFUSCATE("CheckBox_Headshot"),
            OBFUSCATE("CheckBox_Flash"),
            OBFUSCATE("Toggle_The toggle"),
            OBFUSCATE("SeekBar_The slider_1_100"),
            OBFUSCATE("SeekBar_Kittymemory slider example_0_5"),
            OBFUSCATE("Spinner_The spinner_Items 1,Items 2,Items 3"),
            OBFUSCATE("Button_The button"),
            OBFUSCATE("ButtonLink_The button with link_https://www.youtube.com/"),
            OBFUSCATE("ButtonOnOff_The On/Off button"),
            OBFUSCATE("CheckBox_The Check Box"),
            OBFUSCATE("InputValue_The input number"),
            OBFUSCATE("RadioButton_Radio buttons_OFF,Mod 1,Mod 2,Mod 3"),
            OBFUSCATE(
                    "RichTextView_This is text view, not fully HTML."
                    "<b>Bold</b> <i>italic</i> <u>underline</u>"
                    "<br />New line <font color='red'>Support colors</font>"),
            OBFUSCATE(
                    "RichWebView_<html><head><style>body{color: white;}</style></head><body>"
                    "This is WebView, with REAL HTML support!"
                    "<div style=\"background-color: darkblue; text-align: center;\">Support CSS</div>"
                    "<marquee style=\"color: green; font-weight:bold;\" direction=\"left\" scrollamount=\"5\" behavior=\"scroll\">This is <u>scrollable</u> text</marquee>"
                    "</body></html>")
    };

    int Total_Feature = (sizeof features /
                         sizeof features[0]); //Now you dont have to manually update the number everytime;
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));
    int i;
    for (i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    pthread_t ptid;
    pthread_create(&ptid, NULL, antiLeech, NULL);

    return (ret);
}
}
