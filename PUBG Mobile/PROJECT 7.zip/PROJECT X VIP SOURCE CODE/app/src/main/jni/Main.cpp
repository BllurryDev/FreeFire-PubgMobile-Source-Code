/*
 * Credits:
 *
 * Octowolve - Mod menu: https://github.com/z3r0Sec/Substrate-Template-With-Mod-Menu
 * And hooking: https://github.com/z3r0Sec/Substrate-Hooking-Example
 * VanHoevenTR A.K.A Nixi: https://github.com/LGLTeam/VanHoevenTR_Android_Mod_Menu
 * MrIkso - Mod menu: https://github.com/MrIkso/FloatingModMenu
 * Rprop - https://github.com/Rprop/And64InlineHook
 * MJx0 A.K.A Ruit - KittyMemory: https://github.com/MJx0/KittyMemory
 * */
#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include "Includes/obfuscate.h"
#include "KittyMemory/MemoryPatch.h"
#include "Includes/Logger.h"
#include "Includes/Utils.h"
#include "Menu.h"
#include "Toast.h"

#include <Substrate/SubstrateHook.h>
#include <Substrate/CydiaSubstrate.h>

// fancy struct for patches for kittyMemory
struct My_Patches {
    
    MemoryPatch antiban; //0
    MemoryPatch bypass; //1
    MemoryPatch bypass1; //1
    MemoryPatch bypass2; //1
    MemoryPatch bypass3; //1
    MemoryPatch bypass4; //1
    MemoryPatch bypass5; //1
    MemoryPatch bypass6; //1
    MemoryPatch bypass7; //1
    MemoryPatch bypass8; //1
    MemoryPatch bypass9; //1
    MemoryPatch bypass10; //1
    MemoryPatch bypass11; //1
    MemoryPatch bypass12; //1
    MemoryPatch bypass13; //1
    MemoryPatch bypass14; //1
    MemoryPatch bypass15; //1
    MemoryPatch bypass16; //1
    MemoryPatch bypass17; //1
    MemoryPatch bypass18; //1
    MemoryPatch bypass19; //1
    MemoryPatch bypass20; //1
    MemoryPatch bypass21; //1
    MemoryPatch bypass22; //1
    MemoryPatch bypass23; //1
    MemoryPatch bypass24; //1
    MemoryPatch bypass25; //1
    MemoryPatch less; //2
    MemoryPatch noless; //3
    MemoryPatch noless1; //3
    MemoryPatch antina; //2
    MemoryPatch aimbot; //4
    MemoryPatch aimbot1; //4
    MemoryPatch aimbot2; //4
    MemoryPatch magic; //5
    MemoryPatch small; //6
    MemoryPatch wide; //7
    MemoryPatch wide1; //7
    MemoryPatch wide2; //7
    MemoryPatch wide3; //7
    MemoryPatch wide4; //7
    MemoryPatch wide5; //7
    MemoryPatch wide6; //7
    MemoryPatch wide7; //7
    MemoryPatch wide8; //7
    MemoryPatch wide9; //7
    MemoryPatch black; //8
    MemoryPatch nofog; //9
    MemoryPatch flash; //10
    MemoryPatch flash1; //10
    MemoryPatch flash2; //10
    MemoryPatch flash3; //10
    MemoryPatch flash4; //10
    MemoryPatch flash5; //10
    MemoryPatch flash6; //10
    MemoryPatch flash7; //10
    MemoryPatch flash8; //10
    MemoryPatch blacksky; //11
    MemoryPatch longjump;//12
    MemoryPatch bullet;//12

} hexPatches;

bool antiban = false; //1
bool bypass = false; //2
bool less = false; //3
bool noless = false; //4
bool antina = false; //5
bool aimbot = false; //5
bool magic = false; //6
bool small = false; //7
bool wide = false; //8
bool black = false; //9
bool nofog = false; //10
bool flash = false; //11
bool blacksky = false; //12
bool longjump = false; //13
bool bullet = false; //14*/
int sliderValue = 1;

struct {

    bool Gravity = false;

} MG;

bool active = true;
bool launched = false;

#define targetLibName OBFUSCATE("libUE4.so")
#define targetLibName2 OBFUSCATE("libgcloud.so")

extern "C" {
JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_Preferences_Changes(JNIEnv *env, jclass clazz, jobject obj,
                                        jint feature, jint value, jboolean boolean, jstring str) {

    const char *featureName = env->GetStringUTFChars(str, 0);

    LOGD(OBFUSCATE("Feature name: %d - %s | Value: = %d | Bool: = %d"), feature, featureName, value,
         boolean);

    //!!! BE CAREFUL NOT TO ACCIDENTLY REMOVE break; !!!//

    switch (feature) {
        case 1:
            remove("/sdcard/Android/data/com.tencent.ig/cache/GCloud.ini");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Anticheat.ini");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Config/Android/Anticheat.ini");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora/dns.txt");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/GameErrorNoRecords");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/tbslog");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/ca-bundle.pem");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora/dns.txt");
            remove("src/main/java/com/google/errorprone/annotations");
            remove("src/main/java/com/google/errorprone/annotations");
            remove("src/main/java/com/google/errorprone/annotations/concurrent");
            remove("third_party.java_src.error_prone.project.annotations.Google_internal");

            remove("/data/data/com.pubg.krmobile/app_appcache");
            remove("/data/data/com.pubg.krmobile/app_bugly");
            remove("/data/data/com.pubg.krmobile/app_crashrecord");
            remove("/data/data/com.pubg.krmobile/app_databases");
            remove("/data/data/com.pubg.krmobile/app_geolocation");
            remove("/data/data/com.pubg.krmobile/app_tbs");
            remove("/data/data/com.pubg.krmobile/app_textures");
            remove("/data/data/com.pubg.krmobile/app_webview");
            remove("/data/data/com.pubg.krmobile/app_webview_imsdk_inner_webview");
            remove("/data/data/com.pubg.krmobile/cache");
            remove("/data/data/com.pubg.krmobile/code_cache");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/tbslog");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/cache");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/tencent");
            remove("/storage/emulated/0/Tencent");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/login-identifier.txt");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/cacheFile.txt");
            remove("/storage/emulated/0/.backups");
            remove("/data/data/com.pubg.krmobile/app_appcache");
            remove("/data/data/com.pubg.krmobile/app_bugly");
            remove("/data/data/com.pubg.krmobile/app_crashrecord");
            remove("/data/data/com.pubg.krmobile/app_databases");
            remove("/data/data/com.pubg.krmobile/app_geolocation");
            remove("/data/data/com.pubg.krmobile/app_tbs");
            remove("/data/data/com.pubg.krmobile/app_textures");
            remove("/data/data/com.pubg.krmobile/app_webview");
            remove("/data/data/com.pubg.krmobile/app_webview_imsdk_inner_webview");
            remove("/data/data/com.pubg.krmobile/cache");
            remove("/data/data/com.pubg.krmobile/code_cache");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/tbslog");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/cache");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/tencent");
            remove("/storage/emulated/0/Tencent");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/login-identifier.txt");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/cacheFile.txt");
            remove("/storage/emulated/0/.backups");
            remove("/data/data/com.vng.pubgmobile/app_appcache");
            remove("/data/data/com.vng.pubgmobile/app_bugly");
            remove("/data/data/com.vng.pubgmobile/app_crashrecord");
            remove("/data/data/com.vng.pubgmobile/app_databases");
            remove("/data/data/com.vng.pubgmobile/app_geolocation");
            remove("/data/data/com.vng.pubgmobile/app_tbs");
            remove("/data/data/com.vng.pubgmobile/app_textures");
            remove("/data/data/com.vng.pubgmobile/app_webview");
            remove("/data/data/com.vng.pubgmobile/app_webview_imsdk_inner_webview");
            remove("/data/data/com.vng.pubgmobile/cache");
            remove("/data/data/com.vng.pubgmobile/code_cache");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/tbslog");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/cache");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/tencent");
            remove("/storage/emulated/0/Tencent");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/login-identifier.txt");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/cacheFile.txt");
            remove("/storage/emulated/0/.backups");
            remove("/data/data/com.vng.pubgmobile/app_appcache");
            remove("/data/data/com.vng.pubgmobile/app_bugly");
            remove("/data/data/com.vng.pubgmobile/app_crashrecord");
            remove("/data/data/com.vng.pubgmobile/app_databases");
            remove("/data/data/com.vng.pubgmobile/app_geolocation");
            remove("/data/data/com.vng.pubgmobile/app_tbs");
            remove("/data/data/com.vng.pubgmobile/app_textures");
            remove("/data/data/com.vng.pubgmobile/app_webview");
            remove("/data/data/com.vng.pubgmobile/app_webview_imsdk_inner_webview");
            remove("/data/data/com.vng.pubgmobile/cache");
            remove("/data/data/com.vng.pubgmobile/code_cache");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/tbslog");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/cache");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/tencent");
            remove("/storage/emulated/0/Tencent");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/login-identifier.txt");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/cacheFile.txt");
            remove("/storage/emulated/0/.backups");
            remove("/data/data/com.tencent.ig/app_appcache");
            remove("/data/data/com.tencent.ig/app_bugly");
            remove("/data/data/com.tencent.ig/app_crashrecord");
            remove("/data/data/com.tencent.ig/app_databases");
            remove("/data/data/com.tencent.ig/app_geolocation");
            remove("/data/data/com.tencent.ig/app_tbs");
            remove("/data/data/com.tencent.ig/app_textures");
            remove("/data/data/com.tencent.ig/app_webview");
            remove("/data/data/com.tencent.ig/app_webview_imsdk_inner_webview");
            remove("/data/data/com.tencent.ig/cache");
            remove("/data/data/com.tencent.ig/code_cache");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/tbslog");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/cache");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/tencent");
            remove("/storage/emulated/0/Tencent");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/login-identifier.txt");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/cacheFile.txt");
            remove("/storage/emulated/0/.backups");
            remove("/data/data/com.tencent.ig/app_appcache");
            remove("/data/data/com.tencent.ig/app_bugly");
            remove("/data/data/com.tencent.ig/app_crashrecord");
            remove("/data/data/com.tencent.ig/app_databases");
            remove("/data/data/com.tencent.ig/app_geolocation");
            remove("/data/data/com.tencent.ig/app_tbs");
            remove("/data/data/com.tencent.ig/app_textures");
            remove("/data/data/com.tencent.ig/app_webview");
            remove("/data/data/com.tencent.ig/app_webview_imsdk_inner_webview");
            remove("/data/data/com.tencent.ig/cache");
            remove("/data/data/com.tencent.ig/code_cache");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/tbslog");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/cache");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/tencent");
            remove("/storage/emulated/0/Tencent");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/login-identifier.txt");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/cacheFile.txt");
            remove("/storage/emulated/0/.backups");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/cache");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/tbslog");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/ca-bundle.pem");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/cacheFile.txt");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/login-identifier.txt");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/vmpcloudconfig.json");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/ProgramBinaryCache");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir");
            remove("/data/data/com.tencent.ig/app_appcache");
            remove("/data/data/com.tencent.ig/app_bugly");
            remove("/data/data/com.tencent.ig/app_crashrecord");
            remove("/data/data/com.tencent.ig/cache");
            remove("/data/data/com.tencent.ig/code_cache");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/cache");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/tbslog");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/ca-bundle.pem");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/cacheFile.txt");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/login-identifier.txt");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/vmpcloudconfig.json");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/ProgramBinaryCache");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir");
            remove("/data/data/com.pubg.krmobile/app_appcache");
            remove("/data/data/com.pubg.krmobile/app_bugly");
            remove("/data/data/com.pubg.krmobile/app_crashrecord");
            remove("/data/data/com.pubg.krmobile/cache");
            remove("/data/data/com.pubg.krmobile/code_cache");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/cache");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/tbslog");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/ca-bundle.pem");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/cacheFile.txt");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/login-identifier.txt");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/vmpcloudconfig.json");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/ProgramBinaryCache");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir");
            remove("/data/data/com.vng.pubgmobile/app_appcache");
            remove("/data/data/com.vng.pubgmobile/app_bugly");
            remove("/data/data/com.vng.pubgmobile/app_crashrecord");
            remove("/data/data/com.vng.pubgmobile/cache");
            remove("/data/data/com.vng.pubgmobile/code_cache");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/cache");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/tbslog");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/ca-bundle.pem");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/cacheFile.txt");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/login-identifier.txt");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/vmpcloudconfig.json");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/ProgramBinaryCache");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir");
            remove("/data/data/com.rekoo.pubgm/app_appcache");
            remove("/data/data/com.rekoo.pubgm/app_bugly");
            remove("/data/data/com.rekoo.pubgm/app_crashrecord");
            remove("/data/data/com.rekoo.pubgm/cache");
            remove("/data/data/com.rekoo.pubgm/code_cache");
            remove("/data/data/com.pubg.krmobile/app_appcache");
            remove("/data/data/com.pubg.krmobile/app_bugly");
            remove("/data/data/com.pubg.krmobile/app_crashrecord");
            remove("/data/data/com.pubg.krmobile/app_databases");
            remove("/data/data/com.pubg.krmobile/app_geolocation");
            remove("/data/data/com.pubg.krmobile/app_tbs");
            remove("/data/data/com.pubg.krmobile/app_textures");
            remove("/data/data/com.pubg.krmobile/app_webview");
            remove("/data/data/com.pubg.krmobile/app_webview_imsdk_inner_webview");
            remove("/data/data/com.pubg.krmobile/cache");
            remove("/data/data/com.pubg.krmobile/code_cache");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/tbslog");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/cache");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/tencent");
            remove("/storage/emulated/0/Tencent");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/login-identifier.txt");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/cacheFile.txt");
            remove("/storage/emulated/0/.backups");
            remove("/data/data/com.pubg.krmobile/app_appcache");
            remove("/data/data/com.pubg.krmobile/app_bugly");
            remove("/data/data/com.pubg.krmobile/app_crashrecord");
            remove("/data/data/com.pubg.krmobile/app_databases");
            remove("/data/data/com.pubg.krmobile/app_geolocation");
            remove("/data/data/com.pubg.krmobile/app_tbs");
            remove("/data/data/com.pubg.krmobile/app_textures");
            remove("/data/data/com.pubg.krmobile/app_webview");
            remove("/data/data/com.pubg.krmobile/app_webview_imsdk_inner_webview");
            remove("/data/data/com.pubg.krmobile/cache");
            remove("/data/data/com.pubg.krmobile/code_cache");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/tbslog");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/cache");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/tencent");
            remove("/storage/emulated/0/Tencent");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/login-identifier.txt");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/cacheFile.txt");
            remove("/storage/emulated/0/.backups");
            remove("/data/data/com.vng.pubgmobile/app_appcache");
            remove("/data/data/com.vng.pubgmobile/app_bugly");
            remove("/data/data/com.vng.pubgmobile/app_crashrecord");
            remove("/data/data/com.vng.pubgmobile/app_databases");
            remove("/data/data/com.vng.pubgmobile/app_geolocation");
            remove("/data/data/com.vng.pubgmobile/app_tbs");
            remove("/data/data/com.vng.pubgmobile/app_textures");
            remove("/data/data/com.vng.pubgmobile/app_webview");
            remove("/data/data/com.vng.pubgmobile/app_webview_imsdk_inner_webview");
            remove("/data/data/com.vng.pubgmobile/cache");
            remove("/data/data/com.vng.pubgmobile/code_cache");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/tbslog");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/cache");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/tencent");
            remove("/storage/emulated/0/Tencent");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/login-identifier.txt");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/cacheFile.txt");
            remove("/storage/emulated/0/.backups");
            remove("/data/data/com.vng.pubgmobile/app_appcache");
            remove("/data/data/com.vng.pubgmobile/app_bugly");
            remove("/data/data/com.vng.pubgmobile/app_crashrecord");
            remove("/data/data/com.vng.pubgmobile/app_databases");
            remove("/data/data/com.vng.pubgmobile/app_geolocation");
            remove("/data/data/com.vng.pubgmobile/app_tbs");
            remove("/data/data/com.vng.pubgmobile/app_textures");
            remove("/data/data/com.vng.pubgmobile/app_webview");
            remove("/data/data/com.vng.pubgmobile/app_webview_imsdk_inner_webview");
            remove("/data/data/com.vng.pubgmobile/cache");
            remove("/data/data/com.vng.pubgmobile/code_cache");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/tbslog");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/cache");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/tencent");
            remove("/storage/emulated/0/Tencent");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/login-identifier.txt");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/cacheFile.txt");
            remove("/storage/emulated/0/.backups");
            remove("/data/data/com.tencent.ig/app_appcache");
            remove("/data/data/com.tencent.ig/app_bugly");
            remove("/data/data/com.tencent.ig/app_crashrecord");
            remove("/data/data/com.tencent.ig/app_databases");
            remove("/data/data/com.tencent.ig/app_geolocation");
            remove("/data/data/com.tencent.ig/app_tbs");
            remove("/data/data/com.tencent.ig/app_textures");
            remove("/data/data/com.tencent.ig/app_webview");
            remove("/data/data/com.tencent.ig/app_webview_imsdk_inner_webview");
            remove("/data/data/com.tencent.ig/cache");
            remove("/data/data/com.tencent.ig/code_cache");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/tbslog");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/cache");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/tencent");
            remove("/storage/emulated/0/Tencent");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/login-identifier.txt");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/cacheFile.txt");
            remove("/storage/emulated/0/.backups");
            remove("/data/data/com.tencent.ig/app_appcache");
            remove("/data/data/com.tencent.ig/app_bugly");
            remove("/data/data/com.tencent.ig/app_crashrecord");
            remove("/data/data/com.tencent.ig/app_databases");
            remove("/data/data/com.tencent.ig/app_geolocation");
            remove("/data/data/com.tencent.ig/app_tbs");
            remove("/data/data/com.tencent.ig/app_textures");
            remove("/data/data/com.tencent.ig/app_webview");
            remove("/data/data/com.tencent.ig/app_webview_imsdk_inner_webview");
            remove("/data/data/com.tencent.ig/cache");
            remove("/data/data/com.tencent.ig/code_cache");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/tbslog");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/cache");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/tencent");
            remove("/storage/emulated/0/Tencent");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/login-identifier.txt");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/cacheFile.txt");
            remove("/storage/emulated/0/.backups");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/cache");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/tbslog");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/ca-bundle.pem");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/cacheFile.txt");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/login-identifier.txt");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/vmpcloudconfig.json");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/ProgramBinaryCache");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora");
            remove("/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir");
            remove("/data/data/com.tencent.ig/app_appcache");
            remove("/data/data/com.tencent.ig/app_bugly");
            remove("/data/data/com.tencent.ig/app_crashrecord");
            remove("/data/data/com.tencent.ig/cache");
            remove("/data/data/com.tencent.ig/code_cache");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/cache");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/tbslog");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/ca-bundle.pem");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/cacheFile.txt");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/login-identifier.txt");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/vmpcloudconfig.json");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/ProgramBinaryCache");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir");
            remove("/data/data/com.pubg.krmobile/app_appcache");
            remove("/data/data/com.pubg.krmobile/app_bugly");
            remove("/data/data/com.pubg.krmobile/app_crashrecord");
            remove("/data/data/com.pubg.krmobile/cache");
            remove("/data/data/com.pubg.krmobile/code_cache");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/cache");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/tbslog");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/ca-bundle.pem");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/cacheFile.txt");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/login-identifier.txt");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/vmpcloudconfig.json");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/ProgramBinaryCache");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora");
            remove("/storage/emulated/0/Android/data/com.vng.pubgmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir");
            remove("/data/data/com.vng.pubgmobile/app_appcache");
            remove("/data/data/com.vng.pubgmobile/app_bugly");
            remove("/data/data/com.vng.pubgmobile/app_crashrecord");
            remove("/data/data/com.vng.pubgmobile/cache");
            remove("/data/data/com.vng.pubgmobile/code_cache");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/cache");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/tbslog");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/ca-bundle.pem");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/cacheFile.txt");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/login-identifier.txt");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/vmpcloudconfig.json");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/ProgramBinaryCache");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_temp");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/UpdateInfo");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/RoleInfo");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Pandora");
            remove("/storage/emulated/0/Android/data/com.rekoo.pubgm/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/PufferTmpDir");
            remove("/data/data/com.rekoo.pubgm/app_appcache");
            remove("/data/data/com.rekoo.pubgm/app_bugly");
            remove("/data/data/com.rekoo.pubgm/app_crashrecord");
            remove("/data/data/com.rekoo.pubgm/cache");
            remove("/data/data/com.rekoo.pubgm/code_cache");
            remove("third_party.java_src.error_prone.project.annotations.Google_internal");
            break;
        case 2:
            bypass = boolean;
            if (bypass) {
                hexPatches.bypass.Modify();
                hexPatches.bypass1.Modify();
                hexPatches.bypass2.Modify();
                hexPatches.bypass3.Modify();
                hexPatches.bypass4.Modify();
                hexPatches.bypass5.Modify();
                hexPatches.bypass6.Modify();
                hexPatches.bypass7.Modify();
                hexPatches.bypass8.Modify();
                hexPatches.bypass9.Modify();
                hexPatches.bypass10.Modify();
                hexPatches.bypass11.Modify();
                hexPatches.bypass12.Modify();
                hexPatches.bypass13.Modify();
                hexPatches.bypass14.Modify();
                hexPatches.bypass15.Modify();
                hexPatches.bypass16.Modify();
                hexPatches.bypass17.Modify();
                hexPatches.bypass18.Modify();
                hexPatches.bypass19.Modify();
                hexPatches.bypass20.Modify();
                hexPatches.bypass21.Modify();
                hexPatches.bypass22.Modify();
                hexPatches.bypass23.Modify();
                hexPatches.bypass24.Modify();
                hexPatches.bypass25.Modify();
                LOGI(OBFUSCATE("On"));
            } else {
                hexPatches.bypass.Restore();
                hexPatches.bypass1.Restore();
                hexPatches.bypass2.Restore();
                hexPatches.bypass3.Restore();
                hexPatches.bypass4.Restore();
                hexPatches.bypass5.Restore();
                hexPatches.bypass6.Restore();
                hexPatches.bypass7.Restore();
                hexPatches.bypass8.Restore();
                hexPatches.bypass9.Restore();
                hexPatches.bypass10.Restore();
                hexPatches.bypass11.Restore();
                hexPatches.bypass12.Restore();
                hexPatches.bypass13.Restore();
                hexPatches.bypass14.Restore();
                hexPatches.bypass15.Restore();
                hexPatches.bypass16.Restore();
                hexPatches.bypass17.Restore();
                hexPatches.bypass18.Restore();
                hexPatches.bypass19.Restore();
                hexPatches.bypass20.Restore();
                hexPatches.bypass21.Restore();
                hexPatches.bypass22.Restore();
                hexPatches.bypass23.Restore();
                hexPatches.bypass24.Restore();
                hexPatches.bypass25.Restore();
                LOGI(OBFUSCATE("Off"));
            }
            break;
        case 3:
            less = boolean;
            if (less) {
                hexPatches.less.Modify();
                LOGI(OBFUSCATE("On"));
            } else {
                hexPatches.less.Restore();
                LOGI(OBFUSCATE("Off"));
            }
            break;
        case 4:
            noless = boolean;
            if (noless) {
                hexPatches.noless.Modify();
                hexPatches.noless1.Modify();
                LOGI(OBFUSCATE("On"));
            } else {
                hexPatches.noless.Restore();
                hexPatches.noless1.Restore();
                LOGI(OBFUSCATE("Off"));
            }
            break;
        case 15:
            antina = boolean;
            if (antina) {
                hexPatches.antina.Modify();
                LOGI(OBFUSCATE("On"));
            } else {
                hexPatches.antina.Restore();
                LOGI(OBFUSCATE("Off"));
            }
            break;
        case 5:
            aimbot = boolean;
            if (aimbot) {
                hexPatches.aimbot.Modify();
                hexPatches.aimbot1.Modify();
                hexPatches.aimbot2.Modify();
                LOGI(OBFUSCATE("On"));
            } else {
                hexPatches.aimbot.Restore();
                hexPatches.aimbot1.Restore();
                hexPatches.aimbot2.Restore();
                LOGI(OBFUSCATE("Off"));
            }
            break;
        case 6:
            magic = boolean;
            if (magic) {
                hexPatches.magic.Modify();
                LOGI(OBFUSCATE("On"));
            } else {
                hexPatches.magic.Restore();
                LOGI(OBFUSCATE("Off"));
            }
            break;
        case 7:
            small = boolean;
            if (small) {
                hexPatches.small.Modify();
                LOGI(OBFUSCATE("On"));
            } else {
                hexPatches.small.Restore();
                LOGI(OBFUSCATE("Off"));
            }
            break;
        case 8:
            if (value == 0) {
                hexPatches.wide.Restore();
            } else if (value == 1) {
                hexPatches.wide.Modify();
            } else if (value == 2) {
                hexPatches.wide1.Modify();
            } else if (value == 3) {
                hexPatches.wide2.Modify();
            } else if (value == 4) {
                hexPatches.wide3.Modify();
            } else if (value == 5) {
                hexPatches.wide4.Modify();
            } else if (value == 6) {
                hexPatches.wide5.Modify();
            } else if (value == 7) {
                hexPatches.wide6.Modify();
            } else if (value == 8) {
                hexPatches.wide7.Modify();
            } else if (value == 9) {
                hexPatches.wide8.Modify();
            } else if (value == 10) {
                hexPatches.wide9.Modify();
            } 
            
            break;
        case 9:
            black = boolean;
            if (black) {
                hexPatches.black.Modify();
                LOGI(OBFUSCATE("On"));
            } else {
                hexPatches.black.Restore();
                LOGI(OBFUSCATE("Off"));
            }
            break;
        case 10:
            nofog = boolean;
            if (nofog) {
                hexPatches.nofog.Modify();
                LOGI(OBFUSCATE("On"));
            } else {
                hexPatches.nofog.Restore();
                LOGI(OBFUSCATE("Off"));
            }
            break;
        case 11:
            flash = boolean;
            if (flash) {
                hexPatches.flash.Modify();
                hexPatches.flash1.Modify();
                hexPatches.flash2.Modify();
                hexPatches.flash3.Modify();
                hexPatches.flash4.Modify();
                hexPatches.flash5.Modify();
                hexPatches.flash6.Modify();
                hexPatches.flash7.Modify();
                hexPatches.flash8.Modify();
                LOGI(OBFUSCATE("On"));
            } else {
                hexPatches.flash.Restore();
                hexPatches.flash1.Restore();
                hexPatches.flash2.Restore();
                hexPatches.flash3.Restore();
                hexPatches.flash4.Restore();
                hexPatches.flash5.Restore();
                hexPatches.flash6.Restore();
                hexPatches.flash7.Restore();
                hexPatches.flash8.Restore();
                LOGI(OBFUSCATE("Off"));
            }
            break;
        case 12:
            blacksky = boolean;
            if (blacksky) {
                hexPatches.blacksky.Modify();
                LOGI(OBFUSCATE("On"));
            } else {
                hexPatches.blacksky.Restore();
                LOGI(OBFUSCATE("Off"));
            }
            break;
        case 13:
            longjump = boolean;
            if (longjump) {
                hexPatches.longjump.Modify();
                LOGI(OBFUSCATE("On"));
            } else {
                hexPatches.longjump.Restore();
                LOGI(OBFUSCATE("Off"));
            }
            break;
        case 14:
            bullet = boolean;
            if (bullet) {
                hexPatches.bullet.Modify();
                LOGI(OBFUSCATE("On"));
            } else {
                hexPatches.bullet.Restore();
                LOGI(OBFUSCATE("Off"));
            }
            break;
            
            
    }
}
}

void *hack_thread(void *) {
    LOGI(OBFUSCATE("pthread called"));

    //Check if target lib is loaded
    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName));

    LOGI(OBFUSCATE("%s has been loaded"), (const char *) targetLibName);

    
        /*hexPatches.bypass = MemoryPatch::createWithHex(targetLibName,
                                                   string2Offset(OBFUSCATE_KEY("0x1D40C98", '4')),
                                                   OBFUSCATE("00 00 00 00"));
    hexPatches.bypass1 = MemoryPatch::createWithHex(targetLibName,
                                                    string2Offset(OBFUSCATE_KEY("0x1C57DEC", '4')),
                                                    OBFUSCATE("00 00 00 00"));
    hexPatches.bypass2 = MemoryPatch::createWithHex(targetLibName,
                                                    string2Offset(OBFUSCATE_KEY("0x1DBA718", '4')),
                                                    OBFUSCATE("00 00 00 31"));
    hexPatches.bypass3 = MemoryPatch::createWithHex(targetLibName,
                                                    string2Offset(OBFUSCATE_KEY("0x1d40c84", '4')),
                                                    OBFUSCATE("00 00 00 37 "));
    hexPatches.bypass4 = MemoryPatch::createWithHex(targetLibName,
                                                  string2Offset(OBFUSCATE_KEY("0x1d1ddd4", '4')),
                                                  OBFUSCATE("00 00 00 31"));
    hexPatches.bypass5 = MemoryPatch::createWithHex(targetLibName,
                                                    string2Offset(OBFUSCATE_KEY("0x1c55c10", '4')),
                                                    OBFUSCATE("00 00 00 31"));
    hexPatches.bypass6 = MemoryPatch::createWithHex(targetLibName,
                                                   string2Offset(OBFUSCATE_KEY("0x1dba704", '4')),
                                                   OBFUSCATE("00 00 00 33"));
    hexPatches.bypass7 = MemoryPatch::createWithHex(targetLibName,
                                                     string2Offset(OBFUSCATE_KEY("0x1d40d48", '4')),
                                                     OBFUSCATE("00 00 00 00"));
    hexPatches.bypass8 = MemoryPatch::createWithHex(targetLibName,
                                                 string2Offset(OBFUSCATE_KEY("0x1d40cac", '4')),
                                                 OBFUSCATE("00 00 00 00"));
    hexPatches.bypass9 = MemoryPatch::createWithHex(targetLibName,
                                                    string2Offset(OBFUSCATE_KEY("0x1d1dff0", '4')),
                                                    OBFUSCATE("00 00 00 31"));*/

    hexPatches.less = MemoryPatch::createWithHex(targetLibName,
                                                   string2Offset(OBFUSCATE_KEY("0x136D4F8", '4')),
                                                   OBFUSCATE("00 00 00 00"));
    hexPatches.noless = MemoryPatch::createWithHex(targetLibName,
                                                   string2Offset(OBFUSCATE_KEY("0x381CCE0", '4')),
                                                   OBFUSCATE("00 00 34 30"));
    hexPatches.noless1 = MemoryPatch::createWithHex(targetLibName,
                                                   string2Offset(OBFUSCATE_KEY("0x376E57C", '4')),
                                                   OBFUSCATE("00 00 34 30"));
    hexPatches.aimbot = MemoryPatch::createWithHex(targetLibName,
                                                    string2Offset(OBFUSCATE_KEY("0x258B740", '4')),
                                                    OBFUSCATE("01 00 00 7A"));
    hexPatches.aimbot1 = MemoryPatch::createWithHex(targetLibName,
                                                    string2Offset(OBFUSCATE_KEY("0x258B880", '4')),
                                                    OBFUSCATE("00 00 00 00"));
    hexPatches.aimbot2 = MemoryPatch::createWithHex(targetLibName,
                                                    string2Offset(OBFUSCATE_KEY("0x258B74C", '4')),
                                                    OBFUSCATE("00 00 00 00"));
    hexPatches.magic = MemoryPatch::createWithHex(targetLibName,
                                                  string2Offset(OBFUSCATE_KEY("0x3B64788", '4')),
                                                  OBFUSCATE("00 00 20 42"));
    hexPatches.small = MemoryPatch::createWithHex(targetLibName,
                                                    string2Offset(OBFUSCATE_KEY("0x1C113E8", '8')),
                                                    OBFUSCATE("01 00 00 00 10 0A 10 EE"));
    hexPatches.wide = MemoryPatch::createWithHex(targetLibName,
                                                   string2Offset(OBFUSCATE_KEY("0x381FCB0", '4')),
                                                   OBFUSCATE("00 00 B4 43"));
    hexPatches.wide1 = MemoryPatch::createWithHex(targetLibName,
                                                     string2Offset(OBFUSCATE_KEY("0x381FCB0", '4')),
                                                     OBFUSCATE("00 00 AA 43"));
    hexPatches.wide2 = MemoryPatch::createWithHex(targetLibName,
                                                 string2Offset(OBFUSCATE_KEY("0x381FCB0", '4')),
                                                 OBFUSCATE("00 00 A0 43"));
    hexPatches.wide3 = MemoryPatch::createWithHex(targetLibName,
                                                    string2Offset(OBFUSCATE_KEY("0x381FCB0", '4')),
                                                    OBFUSCATE("00 00 96 43"));
    hexPatches.wide4 = MemoryPatch::createWithHex(targetLibName,
                                                   string2Offset(OBFUSCATE_KEY("0x381FCB0", '4')),
                                                   OBFUSCATE("00 00 8C 43"));
    hexPatches.wide5 = MemoryPatch::createWithHex(targetLibName,
                                                       string2Offset(
                                                               OBFUSCATE_KEY("0x381FCB0", '4')),
                                                       OBFUSCATE("00 00 82 43"));
    hexPatches.wide6 = MemoryPatch::createWithHex(targetLibName,
                                                    string2Offset(OBFUSCATE_KEY("0x381FCB0", '4')),
                                                    OBFUSCATE("00 00 70 43"));
    hexPatches.wide7 = MemoryPatch::createWithHex(targetLibName,
                                                   string2Offset(
                                                           OBFUSCATE_KEY("0x381FCB0", '4')),
                                                   OBFUSCATE("00 00 5C 43"));
    hexPatches.wide8 = MemoryPatch::createWithHex(targetLibName,
                                                 string2Offset(OBFUSCATE_KEY("0x381FCB0", '4')),
                                                 OBFUSCATE("00 00 52 43"));
    hexPatches.wide9 = MemoryPatch::createWithHex(targetLibName,
                                                     string2Offset(OBFUSCATE_KEY("0x381FCB0", '4')),
                                                     OBFUSCATE("00 00 48 43"));
    hexPatches.black = MemoryPatch::createWithHex(targetLibName,
                                                    string2Offset(OBFUSCATE_KEY("0x2D96C18", '4')),
                                                    OBFUSCATE("00 00 60 41"));
    hexPatches.nofog = MemoryPatch::createWithHex(targetLibName,
                                                  string2Offset(OBFUSCATE_KEY("0x2D0DA34", '4')),
                                                  OBFUSCATE("00 00 00 00"));
    hexPatches.flash = MemoryPatch::createWithHex(targetLibName,
                                                     string2Offset(OBFUSCATE_KEY("0x3878E8C", '4')),
                                                     OBFUSCATE("00 00 00 00"));
    hexPatches.flash1 = MemoryPatch::createWithHex(targetLibName,
                                                   string2Offset(OBFUSCATE_KEY("0x3878E90", '4')),
                                                   OBFUSCATE("00 00 00 00"));
    hexPatches.flash2 = MemoryPatch::createWithHex(targetLibName,
                                                       string2Offset(
                                                               OBFUSCATE_KEY("0x3878FB4", '4')),
                                                       OBFUSCATE("00 00 00 00"));
    hexPatches.flash3 = MemoryPatch::createWithHex(targetLibName,
                                                    string2Offset(OBFUSCATE_KEY("0x39E9B08", '4')),
                                                    OBFUSCATE("00 00 00 00"));
    hexPatches.flash4 = MemoryPatch::createWithHex(targetLibName,
                                                   string2Offset(
                                                           OBFUSCATE_KEY("0x39E9B10", '4')),
                                                   OBFUSCATE("00 00 00 00"));
    hexPatches.flash5 = MemoryPatch::createWithHex(targetLibName,
                                                 string2Offset(OBFUSCATE_KEY("0x3878FB4", '4')),
                                                 OBFUSCATE("00 00 00 00"));
    hexPatches.flash6 = MemoryPatch::createWithHex(targetLibName,
                                                     string2Offset(OBFUSCATE_KEY("0x3878E90", '4')),
                                                     OBFUSCATE("00 00 00 00"));
    hexPatches.flash7 = MemoryPatch::createWithHex(targetLibName,
                                                    string2Offset(OBFUSCATE_KEY("0x3878E8C", '4')),
                                                    OBFUSCATE("00 00 00 00"));
    hexPatches.flash8 = MemoryPatch::createWithHex(targetLibName,
                                                  string2Offset(OBFUSCATE_KEY("0x130DF0C", '4')),
                                                  OBFUSCATE("00 00 00 00"));

    hexPatches.blacksky = MemoryPatch::createWithHex(targetLibName,
                                                     string2Offset(OBFUSCATE_KEY("0x3AD36A0", '8')),
                                                     OBFUSCATE("B0 C6 27 B7 00 F0 20 E3"));
    hexPatches.longjump = MemoryPatch::createWithHex(targetLibName,
                                                   string2Offset(OBFUSCATE_KEY("0x119BE24", '4')),
                                                   OBFUSCATE("02 1A B7 EE"));
    hexPatches.bullet = MemoryPatch::createWithHex(targetLibName,
                                                   string2Offset(OBFUSCATE_KEY("0x47774F8", '4')),
                                                   OBFUSCATE("00 00 00 00"));
    hexPatches.antina = MemoryPatch::createWithHex(targetLibName,
                                                   string2Offset(OBFUSCATE_KEY("0X25834D8", '4')),
                                                   OBFUSCATE("00 00 00 00"));

    LOGI(OBFUSCATE("Done"));

    return NULL;
}

void *Super_thread(void *) {
    LOGI(OBFUSCATE("pthread called"));

    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName2));

    LOGI(OBFUSCATE("%s has been loaded"), (const char *) targetLibName2);

    hexPatches.bypass = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0x1", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass1 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0x4", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass2 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0x44", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass3 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0x48", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass4 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0x58", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass5 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0x5C", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass6 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0x60", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass7 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0x90", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass8 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0xA4", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass9 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0xA8", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass10 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0xB0", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass11 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0xC4", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass12 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0xC8", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass13 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0xF8", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass14 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0xFC", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass15 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0x100", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass16 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0x104", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass17 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0x108", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass18 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0x124", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass19 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0x128", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass20 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0x1FC", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass21 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0x204", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass22 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0x20C", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass23 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0x1DBC", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass24 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0x1DEC", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    hexPatches.bypass25 = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0x1DCC", '4')),
                                                      OBFUSCATE("00 00 00 00"));
    LOGI(OBFUSCATE("Done"));

    return NULL;
}

/*void *Super_thread(void *) {
    LOGI(OBFUSCATE("pthread called"));

    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName2));

    LOGI(OBFUSCATE("%s has been loaded"), (const char *) targetLibName2);

    hexPatches.NightMode = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0x1A2290", '4')),
                                                      OBFUSCATE("00 00 80 BF"));
    hexPatches.Wallstone = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0xEF37E0", '8')),
                                                      OBFUSCATE("C9 3C 8E BF C9 3C 8E BF"));
    hexPatches.WhiteMode = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0x19ECE4", '4')),
                                                      OBFUSCATE("00 C0 79 44"));
    LOGI(OBFUSCATE("Done"));

    return NULL;
}*/

//No need to use JNI_OnLoad, since we don't use JNIEnv
//We do this to hide OnLoad from disassembler
__attribute__((constructor))
void lib_main() {
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}
