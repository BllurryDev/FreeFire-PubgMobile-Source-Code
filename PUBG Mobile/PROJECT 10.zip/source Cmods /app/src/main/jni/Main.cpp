/*
 * Credits:
 *
 * Octowolve - Mod menu: https://github.com/z3r0Sec/Substrate-Template-With-Mod-Menu
 * And hooking: https://github.com/z3r0Sec/Substrate-Hooking-Example
 * VanHoevenTR A.K.A Nixi: https://github.com/LGLTeam/VanHoevenTR_Android_Mod_Menu
 * MrIkso - Mod menu: https://github.com/MrIkso/FloatingModMenu
 * Rprop - https://github.com/Rprop/And64InlineHook
 * MJx0 A.K.A Ruit - KittyMemory: https://github.com/MJx0/KittyMemory
 * */
#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include "Includes/obfuscate.h"
#include "KittyMemory/MemoryPatch.h"
#include "Includes/Logger.h"
#include "Includes/Utils.h"
#include "Menu.h"
#include "Toast.h"

#include <Substrate/SubstrateHook.h>
#include <Substrate/CydiaSubstrate.h>

// fancy struct for patches for kittyMemory
struct My_Patches {
    
    MemoryPatch antiban; //2
    MemoryPatch less; //3
    MemoryPatch by1; //3
    MemoryPatch by2; //3
    MemoryPatch aimbot; //4
    MemoryPatch aimbot1; //4
    MemoryPatch aimbot2; //4
    MemoryPatch magic; //5
    MemoryPatch by3; //5
    MemoryPatch by4; //5
    MemoryPatch by5; //5
    MemoryPatch small; //6
    MemoryPatch wide; //7
    MemoryPatch wide1; //7
    MemoryPatch wide2; //7
    MemoryPatch wide3; //7
    MemoryPatch wide4; //7
    MemoryPatch wide5; //7
    MemoryPatch wide6; //7
    MemoryPatch wide7; //7
    MemoryPatch wide8; //7
    MemoryPatch wide9; //7
    MemoryPatch black; //8
    MemoryPatch nofog; //9
    MemoryPatch flash; //10
    MemoryPatch blacksky; //11
    MemoryPatch longjump;//12

} hexPatches;

bool antiban = false; //1
bool less = false; //2
bool aimbot = false; //3
bool magic = false; //4
bool small = false; //5
bool wide = false; //6
bool black = false; //7
bool nofog = false; //8
bool flash = false; //9
bool blacksky = false; //10
bool longjump = false; //11
int sliderValue = 1;

struct {

    bool Gravity = false;

} MG;

bool active = true;
bool launched = false;

#define targetLibName OBFUSCATE("libUE4.so")

extern "C" {
JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_Preferences_Changes(JNIEnv *env, jclass clazz, jobject obj,
                                        jint feature, jint value, jboolean boolean, jstring str) {

    const char *featureName = env->GetStringUTFChars(str, 0);

    LOGD(OBFUSCATE("Feature name: %d - %s | Value: = %d | Bool: = %d"), feature, featureName, value,
         boolean);

    //!!! BE CAREFUL NOT TO ACCIDENTLY REMOVE break; !!!//

    switch (feature) { 
        case 1:
            remove("/sdcard/Android/data/com.pubg.krmobile/cache/GCloud.ini");
            remove("/sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/mnt/shell/0/emulated/Android/data/com.pubg.krmobile/cache/GCloud.ini");
            remove("/mnt/shell/0/emulated/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/cache/GCloud.ini");
            remove("/sdcard/Android/data/com.pubg.krmobile/cache/GCloud.ini");
            remove("/sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/mnt/shell/0/emulated/Android/data/com.pubg.krmobile/cache/GCloud.ini");
            remove("/mnt/shell/0/emulated/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/cache/GCloud.ini");
            remove("/sdcard/Android/data/com.pubg.krmobile/cache/GCloud.ini");
            remove("/sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/mnt/shell/0/emulated/Android/data/com.pubg.krmobile/cache/GCloud.ini");
            remove("/mnt/shell/0/emulated/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/cache/GCloud.ini");
            remove("/sdcard/Android/data/com.pubg.krmobile/cache/GCloud.ini");
            remove("/sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/mnt/shell/0/emulated/Android/data/com.pubg.krmobile/cache/GCloud.ini");
            remove("/mnt/shell/0/emulated/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/cache/GCloud.ini");
            remove("/sdcard/Android/data/com.pubg.krmobile/cache/GCloud.ini");
            remove("/sdcard/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Logs");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer-temp");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/1375135419_47_1.1.0.14556_20201210094036_1246353928_cures.ifs.res");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer-temp");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/1375135419_47_1.1.0.14556_20201210094036_1246353928_cures.ifs.res");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer-temp");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/1375135419_47_1.1.0.14556_20201210094036_1246353928_cures.ifs.res");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer-temp");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/1375135419_47_1.1.0.14556_20201210094036_1246353928_cures.ifs.res");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer-temp");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/1375135419_47_1.1.0.14556_20201210094036_1246353928_cures.ifs.res");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer-temp");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/1375135419_47_1.1.0.14556_20201210094036_1246353928_cures.ifs.res");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer-temp");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/1375135419_47_1.1.0.14556_20201210094036_1246353928_cures.ifs.res");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/apollo_reslist.flist");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/filelist.json");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/puffer_res.eifs");
            remove("/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/PufferFileList.json");
            remove("src/main/java/com/google/errorprone/annotations");
            remove("src/main/java/com/google/errorprone/annotations");
            remove("src/main/java/com/google/errorprone/annotations/concurrent");
            remove("third_party.java_src.error_prone.project.annotations.Google_internal");
            break;
        case 2:
            less = boolean;
            if (less) {
                hexPatches.less.Modify();
                hexPatches.by1.Modify();
                hexPatches.by2.Modify();             
                LOGI(OBFUSCATE("On"));
            } else {
                hexPatches.less.Restore();
                hexPatches.by1.Restore();
                hexPatches.by2.Restore();
                LOGI(OBFUSCATE("Off"));
            }
            break;
        case 3:
            aimbot = boolean;
            if (aimbot) {
                hexPatches.aimbot.Modify();
                hexPatches.aimbot1.Modify();
                hexPatches.aimbot2.Modify();
                LOGI(OBFUSCATE("On"));
            } else {
                hexPatches.aimbot.Restore();
                hexPatches.aimbot1.Restore();
                hexPatches.aimbot2.Restore();
                LOGI(OBFUSCATE("Off"));
            }
            break;
        case 4:
            magic = boolean;
            if (magic) {
                hexPatches.magic.Modify();             
                hexPatches.by3.Modify();
                hexPatches.by4.Modify();
                hexPatches.by5.Modify();
                LOGI(OBFUSCATE("On"));
            } else {
                hexPatches.magic.Restore();
                hexPatches.by3.Restore();
                hexPatches.by4.Restore();
                hexPatches.by5.Restore();
                
                
                LOGI(OBFUSCATE("Off"));
            }
            break;
        case 5:
            small = boolean;
            if (small) {
                hexPatches.small.Modify();
                LOGI(OBFUSCATE("On"));
            } else {
                hexPatches.small.Restore();
                LOGI(OBFUSCATE("Off"));
            }
            break;
        case 6:
            if (value == 0) {
                hexPatches.wide.Restore();
            } else if (value == 1) {
                hexPatches.wide.Modify();
            } else if (value == 2) {
                hexPatches.wide1.Modify();
            } else if (value == 3) {
                hexPatches.wide2.Modify();
            } else if (value == 4) {
                hexPatches.wide3.Modify();
            } else if (value == 5) {
                hexPatches.wide4.Modify();
            } else if (value == 6) {
                hexPatches.wide5.Modify();
            } else if (value == 7) {
                hexPatches.wide6.Modify();
            } else if (value == 8) {
                hexPatches.wide7.Modify();
            } else if (value == 9) {
                hexPatches.wide8.Modify();
            } else if (value == 10) {
                hexPatches.wide9.Modify();
            } 
            
            break;
        case 7:
            black = boolean;
            if (black) {
                hexPatches.black.Modify();
                LOGI(OBFUSCATE("On"));
            } else {
                hexPatches.black.Restore();
                LOGI(OBFUSCATE("Off"));
            }
            break;
        case 8:
            nofog = boolean;
            if (nofog) {
                hexPatches.nofog.Modify();
                LOGI(OBFUSCATE("On"));
            } else {
                hexPatches.nofog.Restore();
                LOGI(OBFUSCATE("Off"));
            }
            break;
        case 9:
            flash = boolean;
            if (flash) {
                hexPatches.flash.Modify();
                LOGI(OBFUSCATE("On"));
            } else {
                hexPatches.flash.Restore();
                LOGI(OBFUSCATE("Off"));
            }
            break;
        case 10:
            blacksky = boolean;
            if (blacksky) {
                hexPatches.blacksky.Modify();
                LOGI(OBFUSCATE("On"));
            } else {
                hexPatches.blacksky.Restore();
                LOGI(OBFUSCATE("Off"));
            }
            break;
        case 11:
            longjump = boolean;
            if (longjump) {
                hexPatches.longjump.Modify();
                LOGI(OBFUSCATE("On"));
            } else {
                hexPatches.longjump.Restore();
                LOGI(OBFUSCATE("Off"));
            }
            break;
            
            
    }
}
}

void *hack_thread(void *) {
    LOGI(OBFUSCATE("pthread called"));

    //Check if target lib is loaded
    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName));

    LOGI(OBFUSCATE("%s has been loaded"), (const char *) targetLibName);

    
    hexPatches.by1 = MemoryPatch::createWithHex(targetLibName,
                                                   string2Offset(OBFUSCATE_KEY("0x1D40C98", '4')),
                                                   OBFUSCATE("00 00 00 00"));
  hexPatches.by2 = MemoryPatch::createWithHex(targetLibName,
                                                   string2Offset(OBFUSCATE_KEY("0x1C57DEC", '4')),
                                                   OBFUSCATE("00 00 00 00"));
  hexPatches.by3 = MemoryPatch::createWithHex(targetLibName,
                                                   string2Offset(OBFUSCATE_KEY("0x1DBA718", '4')),
                                                   OBFUSCATE("(00 00 00 31"));
  hexPatches.by4 = MemoryPatch::createWithHex(targetLibName,
                                                   string2Offset(OBFUSCATE_KEY("0x1d40c84", '4')),
                                                   OBFUSCATE("00 00 00 37"));
  hexPatches.by5 = MemoryPatch::createWithHex(targetLibName,
                                                   string2Offset(OBFUSCATE_KEY("0x1d1ddd4", '4')),
                                                   OBFUSCATE("00 00 00 31"));
  
                                                  
    
    
 
    
    hexPatches.less = MemoryPatch::createWithHex(targetLibName,
                                                   string2Offset(OBFUSCATE_KEY("0x136D4F8", '4')),
                                                   OBFUSCATE("00 00 00 00"));
    hexPatches.aimbot = MemoryPatch::createWithHex(targetLibName,
                                                    string2Offset(OBFUSCATE_KEY("0x258B740", '4')),
                                                    OBFUSCATE("01 00 00 7A"));
    hexPatches.aimbot1 = MemoryPatch::createWithHex(targetLibName,
                                                    string2Offset(OBFUSCATE_KEY("0x258B880", '4')),
                                                    OBFUSCATE("00 00 00 00"));
    hexPatches.aimbot2 = MemoryPatch::createWithHex(targetLibName,
                                                    string2Offset(OBFUSCATE_KEY("0x258B74C", '4')),
                                                    OBFUSCATE("00 00 00 00"));
    hexPatches.magic = MemoryPatch::createWithHex(targetLibName,
                                                  string2Offset(OBFUSCATE_KEY("0x3C491D0", '4')),
                                                  OBFUSCATE("00 00 20 42"));
    hexPatches.small = MemoryPatch::createWithHex(targetLibName,
                                                    string2Offset(OBFUSCATE_KEY("0x1C113E8", '4')),
                                                    OBFUSCATE("01 00 00 00 10 0A 10 EE"));
    hexPatches.wide = MemoryPatch::createWithHex(targetLibName,
                                                   string2Offset(OBFUSCATE_KEY("0x381FCB0", '4')),
                                                   OBFUSCATE("00 00 B4 43"));
    hexPatches.wide1 = MemoryPatch::createWithHex(targetLibName,
                                                     string2Offset(OBFUSCATE_KEY("0x381FCB0", '4')),
                                                     OBFUSCATE("00 00 AA 43"));
    hexPatches.wide2 = MemoryPatch::createWithHex(targetLibName,
                                                 string2Offset(OBFUSCATE_KEY("0x381FCB0", '4')),
                                                 OBFUSCATE("00 00 A0 43"));
    hexPatches.wide3 = MemoryPatch::createWithHex(targetLibName,
                                                    string2Offset(OBFUSCATE_KEY("0x381FCB0", '4')),
                                                    OBFUSCATE("00 00 96 43"));
    hexPatches.wide4 = MemoryPatch::createWithHex(targetLibName,
                                                   string2Offset(OBFUSCATE_KEY("0x381FCB0", '4')),
                                                   OBFUSCATE("00 00 8C 43"));
    hexPatches.wide5 = MemoryPatch::createWithHex(targetLibName,
                                                       string2Offset(
                                                               OBFUSCATE_KEY("0x381FCB0", '4')),
                                                       OBFUSCATE("00 00 82 43"));
    hexPatches.wide6 = MemoryPatch::createWithHex(targetLibName,
                                                    string2Offset(OBFUSCATE_KEY("0x381FCB0", '4')),
                                                    OBFUSCATE("00 00 70 43"));
    hexPatches.wide7 = MemoryPatch::createWithHex(targetLibName,
                                                   string2Offset(
                                                           OBFUSCATE_KEY("0x381FCB0", '4')),
                                                   OBFUSCATE("00 00 5C 43"));
    hexPatches.wide8 = MemoryPatch::createWithHex(targetLibName,
                                                 string2Offset(OBFUSCATE_KEY("0x381FCB0", '4')),
                                                 OBFUSCATE("00 00 52 43"));
    hexPatches.wide9 = MemoryPatch::createWithHex(targetLibName,
                                                     string2Offset(OBFUSCATE_KEY("0x381FCB0", '4')),
                                                     OBFUSCATE("00 00 48 43"));
    hexPatches.black = MemoryPatch::createWithHex(targetLibName,
                                                    string2Offset(OBFUSCATE_KEY("0x2D96C18", '4')),
                                                    OBFUSCATE("00 00 60 41"));
    hexPatches.nofog = MemoryPatch::createWithHex(targetLibName,
                                                  string2Offset(OBFUSCATE_KEY("0x2D0DA34", '4')),
                                                  OBFUSCATE("00 00 00 00"));
    hexPatches.flash = MemoryPatch::createWithHex(targetLibName,
                                                     string2Offset(OBFUSCATE_KEY("0x3F109B0", '4')),
                                                     OBFUSCATE("00 00 00 00"));
    hexPatches.blacksky = MemoryPatch::createWithHex(targetLibName,
                                                     string2Offset(OBFUSCATE_KEY("0x3AD36A0", '8')),
                                                     OBFUSCATE("B0 C6 27 B7 00 F0 20 E3"));
    hexPatches.longjump = MemoryPatch::createWithHex(targetLibName,
                                                   string2Offset(OBFUSCATE_KEY("0x119BE24", '4')),
                                                   OBFUSCATE("02 1A B7 EE"));

    LOGI(OBFUSCATE("Done"));

    return NULL;
}

/*void *Super_thread(void *) {
    LOGI(OBFUSCATE("pthread called"));

    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName2));

    LOGI(OBFUSCATE("%s has been loaded"), (const char *) targetLibName2);

    hexPatches.NightMode = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0x1A2290", '4')),
                                                      OBFUSCATE("00 00 80 BF"));
    hexPatches.Wallstone = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0xEF37E0", '8')),
                                                      OBFUSCATE("C9 3C 8E BF C9 3C 8E BF"));
    hexPatches.WhiteMode = MemoryPatch::createWithHex(targetLibName2,
                                                      string2Offset(OBFUSCATE_KEY("0x19ECE4", '4')),
                                                      OBFUSCATE("00 C0 79 44"));
    LOGI(OBFUSCATE("Done"));

    return NULL;
}*/

//No need to use JNI_OnLoad, since we don't use JNIEnv
//We do this to hide OnLoad from disassembler
__attribute__((constructor))
void lib_main() {
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}
