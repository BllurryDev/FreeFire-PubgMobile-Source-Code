# PUBGM-ESP-AIMBOT-PC-Gameloop
Gameloop PC Pubg Mobile 1.0.0 ESP &amp; AIMBOT Hack using BypaPH, bypasses process read/write restrictions.

# Youtube Video

https://youtu.be/mcQArbpJEjE

# Tools:
- C#
- VS2019

Features:
- Player ESP (2d box, 3d box,skeleton, ignore teammate, identify bot)
- Item/Lootbox ESP
- Vehicle ESP
- Grenade Alert
- Player Health/Name/Distance/Line
- Simple Aimbot
- Enemy State
- Enemy Weapon

# Contact 
- Discord Only : Ahmed Moorsy#6939

# References :-
- Google.
- Youtube.
- unknowncheats.
- https://github.com/fly8888/pubg-mobile-esp
- https://github.com/huddhudd/crappy-esp
- https://www.unknowncheats.me/forum/pubg-mobile/354946-source-code-esp-pubg-mobile-0-16-5-safu_iraq.html
- https://www.unknowncheats.me/forum/pubg-mobile/379241-esp-source-pubgm-v0-17-0-gameloop.html
