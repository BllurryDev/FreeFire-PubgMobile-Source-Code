﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PUBGMESP
{
    internal class Patterns
    {
        #region ESP
        public static string viewWorldSearch = "02 00 00 00 80 00 00 00 FF FF FF FF 00 00 00 00 01";
        #endregion
    }
}
