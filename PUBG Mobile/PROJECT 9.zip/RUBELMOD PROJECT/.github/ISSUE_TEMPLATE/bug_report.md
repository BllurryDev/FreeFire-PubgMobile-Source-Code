---
name: Bug report modded game
about: Report an issue with injected mod menu in modded APK
title: ''
labels: ''
assignees: ''

---

<!-- Replace the bracketed [...] placeholders with your own information. -->
<!-- Failure to fill out details will result the issue being closed, with or without notice! -->

<!-- THIS IS FOR ISSUE WITH INJECTED MOD MENU IN A MODDED APK ONLY. Do not post an issue with hooking and patching in game. We don't offer support with it. End users must understand c++ and pointers. Instead please go to any modding forum communuty for help with this. -->

### Describe the bug
<!-- [A clear and concise description of what the bug is.] -->

### Screenshot(s) or video
<!-- [If applicable, add screenshots or video to help explain your problem.] -->

### Logcat
<!-- [LOGCAT IS VERY IMPORTANT SO WE CAN EASLY SEE WHAT WENT WRONG] -->

```
Include logcat here
If the logcat is too long, please post on pastebin.com and link here instead
```

### Link to game
<!-- [Link to PlayStore, APKPure or similar] -->

### Link to modded APK (Optional)
<!-- [If applicable, link your modded APK here. Recommended if you contact me private] -->
