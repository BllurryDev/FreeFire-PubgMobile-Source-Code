#ifndef LGL_IL2CPP_MENU_TOAST_H
#define LGL_IL2CPP_MENU_TOAST_H

extern "C" {
JNIEXPORT void JNICALL
Java_rubel_mod_main_Toast(JNIEnv *env, jclass obj, jobject context) {
     MakeToast(env, context, OBFUSCATE(" { RUBELMOD } "), Toast::LENGTH_LONG);
     MakeToast(env, context, OBFUSCATE("JOIN HERE"), Toast::LENGTH_LONG);
     MakeToast(env, context, OBFUSCATE("JOIN: @Rubel_Mod"), Toast::LENGTH_LONG);
}
}

#endif //LGL_IL2CPP_MENU_TOAST_H
